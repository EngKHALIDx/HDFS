package com.smarthdfs;

import com.smarthdfs.aggregator.BufferedFile;
import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.index.IndexEntry;
import com.smarthdfs.index.IndexManager;
import com.smarthdfs.util.HdfsUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Smart HDFS Client Library components.
 * These tests verify the core functionality without requiring a real HDFS cluster.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
class SmartHdfsClientTest {
    
    private SmartHdfsConfig config;
    
    @BeforeEach
    void setUp() {
        config = SmartHdfsConfig.builder()
                .blockSize(128 * 1024 * 1024)
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)
                .flushIntervalMs(30000)
                .enableAutoFlush(true)
                .transparentMode(true)
                .build();
    }
    
    @Test
    @DisplayName("Test SmartHdfsConfig default values")
    void testConfigDefaults() {
        SmartHdfsConfig defaultConfig = new SmartHdfsConfig();
        
        assertEquals(128 * 1024 * 1024L, defaultConfig.getBlockSize());
        assertEquals(128 * 1024 * 1024L, defaultConfig.getSmallFileThreshold());
        assertEquals(64 * 1024 * 1024, defaultConfig.getBufferSize());
        assertTrue(defaultConfig.isEnableAutoFlush());
        assertTrue(defaultConfig.isTransparentMode());
    }
    
    @Test
    @DisplayName("Test SmartHdfsConfig builder")
    void testConfigBuilder() {
        SmartHdfsConfig customConfig = SmartHdfsConfig.builder()
                .blockSize(256 * 1024 * 1024)
                .smallFileThreshold(64 * 1024 * 1024)
                .bufferSize(32 * 1024 * 1024)
                .enableAutoFlush(false)
                .transparentMode(false)
                .build();
        
        assertEquals(256 * 1024 * 1024L, customConfig.getBlockSize());
        assertEquals(64 * 1024 * 1024L, customConfig.getSmallFileThreshold());
        assertEquals(32 * 1024 * 1024, customConfig.getBufferSize());
        assertFalse(customConfig.isEnableAutoFlush());
        assertFalse(customConfig.isTransparentMode());
    }
    
    @Test
    @DisplayName("Test BufferedFile creation")
    void testBufferedFileCreation() {
        String fileName = "/data/test/file.txt";
        byte[] data = "Hello, World!".getBytes();
        
        BufferedFile bufferedFile = new BufferedFile(fileName, data);
        
        assertEquals(fileName, bufferedFile.getFileName());
        assertEquals(data.length, bufferedFile.getSize());
        assertArrayEquals(data, bufferedFile.getData());
        assertFalse(bufferedFile.isWritten());
        assertEquals(-1, bufferedFile.getOffsetInContainer());
    }
    
    @Test
    @DisplayName("Test BufferedFile metadata update")
    void testBufferedFileMetadata() {
        BufferedFile file = new BufferedFile("/test.txt", "data".getBytes());
        
        file.setContainerName("container_001.seq");
        file.setOffsetInContainer(1024);
        file.setWritten(true);
        
        assertEquals("container_001.seq", file.getContainerName());
        assertEquals(1024, file.getOffsetInContainer());
        assertTrue(file.isWritten());
    }
    
    @Test
    @DisplayName("Test IndexEntry creation and comparison")
    void testIndexEntry() {
        IndexEntry entry1 = new IndexEntry("/file1.txt", "container.seq", 0, 100);
        IndexEntry entry2 = new IndexEntry("/file2.txt", "container.seq", 100, 200);
        IndexEntry entry3 = new IndexEntry("/file1.txt", "other.seq", 500, 150);
        
        assertEquals("/file1.txt", entry1.getFileName());
        assertEquals("container.seq", entry1.getContainerName());
        assertEquals(0, entry1.getOffset());
        assertEquals(100, entry1.getSize());
        
        // Test equality based on file name
        assertEquals(entry1, entry3);
        assertNotEquals(entry1, entry2);
        
        // Test comparison
        assertTrue(entry1.compareTo(entry2) < 0);
    }
    
    @Test
    @DisplayName("Test HdfsUtils formatSize")
    void testFormatSize() {
        assertEquals("100 B", HdfsUtils.formatSize(100));
        assertEquals("1.00 KB", HdfsUtils.formatSize(1024));
        assertEquals("1.50 KB", HdfsUtils.formatSize(1536));
        assertEquals("1.00 MB", HdfsUtils.formatSize(1024 * 1024));
        assertEquals("1.00 GB", HdfsUtils.formatSize(1024L * 1024 * 1024));
        assertEquals("1.00 TB", HdfsUtils.formatSize(1024L * 1024 * 1024 * 1024));
    }
    
    @Test
    @DisplayName("Test HdfsUtils estimateNameNodeMemory")
    void testEstimateNameNodeMemory() {
        // Each file uses ~150 bytes
        long memory1 = HdfsUtils.estimateNameNodeMemory(1000);
        assertEquals(150000, memory1);
        
        long memory2 = HdfsUtils.estimateNameNodeMemory(1000000);
        assertEquals(150000000, memory2); // 150 MB for 1M files
    }
    
    @Test
    @DisplayName("Test HdfsUtils calculateMemorySavings")
    void testCalculateMemorySavings() {
        // 10000 files reduced to 100 containers
        long savings = HdfsUtils.calculateMemorySavings(10000, 100);
        
        // Original: 10000 * 150 = 1,500,000 bytes
        // Container: 100 * 150 = 15,000 bytes
        // Savings: 1,485,000 bytes
        assertEquals(1485000, savings);
    }
    
    @Test
    @DisplayName("Test HdfsUtils calculateReductionRatio")
    void testCalculateReductionRatio() {
        // 100 reduced to 10 = 90% reduction
        double ratio = HdfsUtils.calculateReductionRatio(100, 10);
        assertEquals(90.0, ratio, 0.01);
        
        // No reduction
        double noChange = HdfsUtils.calculateReductionRatio(100, 100);
        assertEquals(0.0, noChange, 0.01);
    }
    
    @Test
    @DisplayName("Test HdfsUtils path operations")
    void testPathOperations() {
        // Valid paths
        assertTrue(HdfsUtils.isValidPath("/data/files/test.txt"));
        assertTrue(HdfsUtils.isValidPath("hdfs://namenode:9000/data/file.csv"));
        
        // Invalid paths
        assertFalse(HdfsUtils.isValidPath(null));
        assertFalse(HdfsUtils.isValidPath(""));
        assertFalse(HdfsUtils.isValidPath("/data/file<test>.txt"));
        
        // Extract file name
        assertEquals("file.txt", HdfsUtils.extractFileName("/data/path/file.txt"));
        assertEquals("file.txt", HdfsUtils.extractFileName("file.txt"));
        
        // Extract directory
        assertEquals("/data/path", HdfsUtils.extractDirectory("/data/path/file.txt"));
        assertEquals("", HdfsUtils.extractDirectory("file.txt"));
    }
    
    @Test
    @DisplayName("Test HdfsUtils generateUniqueFileName")
    void testGenerateUniqueFileName() {
        String name1 = HdfsUtils.generateUniqueFileName("container", "seq");
        String name2 = HdfsUtils.generateUniqueFileName("container", "seq");
        
        assertTrue(name1.startsWith("container_"));
        assertTrue(name1.endsWith(".seq"));
        assertNotEquals(name1, name2); // Should be unique
    }
    
    @Test
    @DisplayName("Test HdfsUtils estimateContainerCount")
    void testEstimateContainerCount() {
        // 10000 files of 100KB each = ~1GB total
        // With 128MB containers, expect ~8 containers
        int containers = HdfsUtils.estimateContainerCount(10000, 128 * 1024 * 1024, 100 * 1024);
        assertEquals(8, containers);
    }
    
    @Test
    @DisplayName("Test HdfsUtils throughput calculation")
    void testThroughputCalculation() {
        // 1GB in 10 seconds = 100MB/s
        double throughput = HdfsUtils.calculateThroughput(1024L * 1024 * 1024, 10000);
        assertEquals(107374182.4, throughput, 0.1); // ~100MB/s
        
        String formatted = HdfsUtils.formatThroughput(throughput);
        assertTrue(formatted.contains("MB"));
    }
    
    @Test
    @DisplayName("Test SmartHdfsConfig compression type")
    void testCompressionType() {
        SmartHdfsConfig compressionConfig = SmartHdfsConfig.builder()
                .enableCompression(true)
                .compressionType(SmartHdfsConfig.CompressionType.SNAPPY)
                .build();
        
        assertTrue(compressionConfig.isEnableCompression());
        assertEquals(SmartHdfsConfig.CompressionType.SNAPPY, compressionConfig.getCompressionType());
    }
    
    @Test
    @DisplayName("Test IndexEntry serialization")
    void testIndexEntrySerialization() throws Exception {
        IndexEntry original = new IndexEntry("/test/file.txt", "container_001.seq", 12345, 6789);
        
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        java.io.DataOutputStream out = new java.io.DataOutputStream(baos);
        
        original.write(out);
        
        java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(baos.toByteArray());
        java.io.DataInputStream in = new java.io.DataInputStream(bais);
        
        IndexEntry deserialized = IndexEntry.read(in);
        
        assertEquals(original.getFileName(), deserialized.getFileName());
        assertEquals(original.getContainerName(), deserialized.getContainerName());
        assertEquals(original.getOffset(), deserialized.getOffset());
        assertEquals(original.getSize(), deserialized.getSize());
    }
    
    @Test
    @DisplayName("Test SmartHdfsConfig toString")
    void testConfigToString() {
        String str = config.toString();
        
        assertTrue(str.contains("blockSize"));
        assertTrue(str.contains("smallFileThreshold"));
        assertTrue(str.contains("bufferSize"));
        assertTrue(str.contains("transparentMode"));
    }
    
    @Test
    @DisplayName("Test BufferedFile toString")
    void testBufferedFileToString() {
        BufferedFile file = new BufferedFile("/data/test.csv", "test,data".getBytes());
        String str = file.toString();
        
        assertTrue(str.contains("/data/test.csv"));
        assertTrue(str.contains("size=10"));
    }
}
