package com.smarthdfs.index;

import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Index Manager - Manages the side-car index for fast file lookup.
 * 
 * The index maps small file names to their locations in container files.
 * It uses a two-level structure:
 * 1. In-memory cache (ConcurrentHashMap) for fast lookups
 * 2. Persistent index files stored in HDFS
 * 
 * Index File Format (CSV):
 * fileName,containerName,offset,size,timestamp
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class IndexManager {
    
    private static final Logger LOG = LoggerFactory.getLogger(IndexManager.class);
    
    private final SmartHdfsConfig config;
    private final FileSystem fileSystem;
    
    // Main index: fileName -> IndexEntry
    private final Map<String, IndexEntry> index;
    
    // Container index: containerName -> Map of files in that container
    private final Map<String, Map<String, IndexEntry>> containerIndex;
    
    // Lock for thread-safe operations
    private final ReentrantReadWriteLock lock;
    
    // Index file path
    private final Path indexPath;
    
    // Statistics
    private long totalEntries;
    private long lastPersistTime;
    
    /**
     * Constructor for IndexManager
     * 
     * @param config The configuration
     * @param fileSystem The HDFS filesystem
     * @throws IOException If initialization fails
     */
    public IndexManager(SmartHdfsConfig config, FileSystem fileSystem) throws IOException {
        this.config = config;
        this.fileSystem = fileSystem;
        
        this.index = new ConcurrentHashMap<>(config.getIndexCacheSize());
        this.containerIndex = new ConcurrentHashMap<>();
        
        this.lock = new ReentrantReadWriteLock();
        
        this.indexPath = new Path(config.getContainerDir(), "master_index" + config.getIndexSuffix());
        
        this.totalEntries = 0;
        this.lastPersistTime = 0;
        
        // Load existing index if available
        loadMasterIndex();
        
        LOG.info("IndexManager initialized with {} existing entries", totalEntries);
    }
    
    /**
     * Add an entry to the index
     * 
     * @param entry The index entry to add
     */
    public void addEntry(IndexEntry entry) {
        lock.writeLock().lock();
        try {
            index.put(entry.getFileName(), entry);
            
            // Also add to container index
            containerIndex.computeIfAbsent(entry.getContainerName(), k -> new ConcurrentHashMap<>())
                         .put(entry.getFileName(), entry);
            
            totalEntries++;
            
            LOG.debug("Added index entry: {} -> container={}, offset={}", 
                     entry.getFileName(), entry.getContainerName(), entry.getOffset());
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get an entry from the index
     * 
     * @param fileName The file name to look up
     * @return The index entry, or null if not found
     */
    public IndexEntry getEntry(String fileName) {
        lock.readLock().lock();
        try {
            return index.get(fileName);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Check if a file exists in the index
     * 
     * @param fileName The file name to check
     * @return true if the file exists in the index
     */
    public boolean containsFile(String fileName) {
        lock.readLock().lock();
        try {
            return index.containsKey(fileName);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Remove an entry from the index
     * 
     * @param fileName The file name to remove
     * @return The removed entry, or null if not found
     */
    public IndexEntry removeEntry(String fileName) {
        lock.writeLock().lock();
        try {
            IndexEntry entry = index.remove(fileName);
            
            if (entry != null) {
                // Also remove from container index
                Map<String, IndexEntry> containerFiles = containerIndex.get(entry.getContainerName());
                if (containerFiles != null) {
                    containerFiles.remove(fileName);
                    if (containerFiles.isEmpty()) {
                        containerIndex.remove(entry.getContainerName());
                    }
                }
                totalEntries--;
            }
            
            return entry;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get all entries in a container
     * 
     * @param containerName The container name
     * @return Collection of entries in the container
     */
    public Collection<IndexEntry> getContainerEntries(String containerName) {
        lock.readLock().lock();
        try {
            Map<String, IndexEntry> containerFiles = containerIndex.get(containerName);
            return containerFiles != null ? containerFiles.values() : null;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Persist the index for a specific container
     * 
     * @param containerName The container name
     * @throws IOException If an I/O error occurs
     */
    public void persistIndex(String containerName) throws IOException {
        lock.readLock().lock();
        try {
            Path containerIndexPath = new Path(config.getContainerDir(), 
                                              containerName + config.getIndexSuffix());
            
            Map<String, IndexEntry> containerFiles = containerIndex.get(containerName);
            if (containerFiles == null || containerFiles.isEmpty()) {
                return;
            }
            
            try (FSDataOutputStream out = fileSystem.create(containerIndexPath, true);
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out))) {
                
                // Write header
                writer.write("# Smart HDFS Index File");
                writer.newLine();
                writer.write("# Format: fileName,containerName,offset,size,timestamp");
                writer.newLine();
                
                // Write entries
                for (IndexEntry entry : containerFiles.values()) {
                    writer.write(formatEntry(entry));
                    writer.newLine();
                }
            }
            
            LOG.debug("Persisted index for container {} with {} entries", 
                     containerName, containerFiles.size());
            
        } finally {
            lock.readLock().unlock();
        }
        
        // Also update master index
        persistMasterIndex();
    }
    
    /**
     * Persist the master index containing all entries
     * 
     * @throws IOException If an I/O error occurs
     */
    public void persistMasterIndex() throws IOException {
        lock.readLock().lock();
        try {
            try (FSDataOutputStream out = fileSystem.create(indexPath, true);
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out))) {
                
                // Write header
                writer.write("# Smart HDFS Master Index File");
                writer.newLine();
                writer.write("# Format: fileName,containerName,offset,size,timestamp");
                writer.newLine();
                writer.write("# Generated: " + System.currentTimeMillis());
                writer.newLine();
                
                // Write all entries
                for (IndexEntry entry : index.values()) {
                    writer.write(formatEntry(entry));
                    writer.newLine();
                }
            }
            
            lastPersistTime = System.currentTimeMillis();
            LOG.debug("Persisted master index with {} entries", index.size());
            
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Load the master index from HDFS
     * 
     * @throws IOException If an I/O error occurs
     */
    private void loadMasterIndex() throws IOException {
        if (!fileSystem.exists(indexPath)) {
            LOG.info("Master index file not found, starting with empty index");
            return;
        }
        
        try (FSDataInputStream in = fileSystem.open(indexPath);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            
            String line;
            while ((line = reader.readLine()) != null) {
                // Skip comments
                if (line.startsWith("#") || line.trim().isEmpty()) {
                    continue;
                }
                
                IndexEntry entry = parseEntry(line);
                if (entry != null) {
                    index.put(entry.getFileName(), entry);
                    
                    // Also add to container index
                    containerIndex.computeIfAbsent(entry.getContainerName(), k -> new ConcurrentHashMap<>())
                                 .put(entry.getFileName(), entry);
                    
                    totalEntries++;
                }
            }
        }
        
        LOG.info("Loaded {} entries from master index", totalEntries);
    }
    
    /**
     * Format an entry for storage
     * 
     * @param entry The entry to format
     * @return Formatted string
     */
    private String formatEntry(IndexEntry entry) {
        return String.format("%s,%s,%d,%d,%d",
                entry.getFileName(),
                entry.getContainerName(),
                entry.getOffset(),
                entry.getSize(),
                entry.getTimestamp());
    }
    
    /**
     * Parse an entry from storage format
     * 
     * @param line The line to parse
     * @return The parsed IndexEntry, or null if parsing fails
     */
    private IndexEntry parseEntry(String line) {
        try {
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                IndexEntry entry = new IndexEntry();
                entry.setFileName(parts[0]);
                entry.setContainerName(parts[1]);
                entry.setOffset(Long.parseLong(parts[2]));
                entry.setSize(Long.parseLong(parts[3]));
                if (parts.length >= 5) {
                    entry.setTimestamp(Long.parseLong(parts[4]));
                }
                return entry;
            }
        } catch (Exception e) {
            LOG.warn("Failed to parse index entry: {}", line, e);
        }
        return null;
    }
    
    /**
     * Get the total number of indexed files
     * 
     * @return The number of indexed files
     */
    public long getEntryCount() {
        lock.readLock().lock();
        try {
            return index.size();
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Get the number of containers
     * 
     * @return The number of containers
     */
    public int getContainerCount() {
        lock.readLock().lock();
        try {
            return containerIndex.size();
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Get all file names in the index
     * 
     * @return Collection of file names
     */
    public Collection<String> getAllFileNames() {
        lock.readLock().lock();
        try {
            return index.keySet();
        } finally {
            lock.readLock().unlock();
        }
    }
    
    /**
     * Clear the entire index
     */
    public void clear() {
        lock.writeLock().lock();
        try {
            index.clear();
            containerIndex.clear();
            totalEntries = 0;
            LOG.info("Index cleared");
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    /**
     * Get index statistics
     * 
     * @return Map of statistics
     */
    public Map<String, Object> getStatistics() {
        lock.readLock().lock();
        try {
            Map<String, Object> stats = new ConcurrentHashMap<>();
            stats.put("totalEntries", index.size());
            stats.put("containerCount", containerIndex.size());
            stats.put("lastPersistTime", lastPersistTime);
            
            // Calculate average files per container
            double avgFilesPerContainer = containerIndex.isEmpty() ? 0 :
                    (double) index.size() / containerIndex.size();
            stats.put("avgFilesPerContainer", avgFilesPerContainer);
            
            return stats;
        } finally {
            lock.readLock().unlock();
        }
    }
}
