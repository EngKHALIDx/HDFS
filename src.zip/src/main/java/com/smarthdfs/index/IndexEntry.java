package com.smarthdfs.index;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.Serializable;

/**
 * Represents an index entry that maps a small file to its location
 * within a container file (SequenceFile).
 * 
 * The index entry contains:
 * - File name: The original file path
 * - Container name: The SequenceFile containing this file
 * - Offset: The byte offset within the container
 * - Size: The file size in bytes
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class IndexEntry implements Serializable, Comparable<IndexEntry> {
    
    private static final long serialVersionUID = 1L;
    
    private String fileName;
    private String containerName;
    private long offset;
    private long size;
    private long timestamp;
    
    /**
     * Default constructor for serialization
     */
    public IndexEntry() {
        this.timestamp = System.currentTimeMillis();
    }
    
    /**
     * Constructor with all fields
     * 
     * @param fileName The file name/path
     * @param containerName The container file name
     * @param offset The byte offset in the container
     * @param size The file size in bytes
     */
    public IndexEntry(String fileName, String containerName, long offset, long size) {
        this.fileName = fileName;
        this.containerName = containerName;
        this.offset = offset;
        this.size = size;
        this.timestamp = System.currentTimeMillis();
    }
    
    // Getters and Setters
    
    public String getFileName() {
        return fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public String getContainerName() {
        return containerName;
    }
    
    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }
    
    public long getOffset() {
        return offset;
    }
    
    public void setOffset(long offset) {
        this.offset = offset;
    }
    
    public long getSize() {
        return size;
    }
    
    public void setSize(long size) {
        this.size = size;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    /**
     * Write this entry to a DataOutput
     * 
     * @param out The data output
     * @throws IOException If an I/O error occurs
     */
    public void write(DataOutput out) throws IOException {
        out.writeUTF(fileName != null ? fileName : "");
        out.writeUTF(containerName != null ? containerName : "");
        out.writeLong(offset);
        out.writeLong(size);
        out.writeLong(timestamp);
    }
    
    /**
     * Read this entry from a DataInput
     * 
     * @param in The data input
     * @throws IOException If an I/O error occurs
     */
    public void readFields(DataInput in) throws IOException {
        fileName = in.readUTF();
        containerName = in.readUTF();
        offset = in.readLong();
        size = in.readLong();
        timestamp = in.readLong();
    }
    
    /**
     * Create an IndexEntry from a DataInput
     * 
     * @param in The data input
     * @return The created IndexEntry
     * @throws IOException If an I/O error occurs
     */
    public static IndexEntry read(DataInput in) throws IOException {
        IndexEntry entry = new IndexEntry();
        entry.readFields(in);
        return entry;
    }
    
    @Override
    public int compareTo(IndexEntry other) {
        return this.fileName.compareTo(other.fileName);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        IndexEntry that = (IndexEntry) obj;
        return fileName != null ? fileName.equals(that.fileName) : that.fileName == null;
    }
    
    @Override
    public int hashCode() {
        return fileName != null ? fileName.hashCode() : 0;
    }
    
    @Override
    public String toString() {
        return "IndexEntry{" +
                "fileName='" + fileName + '\'' +
                ", containerName='" + containerName + '\'' +
                ", offset=" + offset +
                ", size=" + size +
                ", timestamp=" + timestamp +
                '}';
    }
}
