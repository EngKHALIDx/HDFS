package com.smarthdfs.interception;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.PositionedReadable;
import org.apache.hadoop.fs.Seekable;

import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
 * ByteArrayFSDataInputStream - A FSDataInputStream implementation that wraps
 * a byte array. Used to return data from aggregated files through the
 * standard HDFS input stream interface.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class ByteArrayFSDataInputStream extends FSDataInputStream implements Seekable, PositionedReadable {
    
    private final ByteArrayInputStream inputStream;
    private final byte[] data;
    
    /**
     * Constructor for ByteArrayFSDataInputStream
     * 
     * @param data The byte array to read from
     */
    public ByteArrayFSDataInputStream(byte[] data) {
        super(new ByteArrayInputStream(data));
        this.inputStream = (ByteArrayInputStream) in;
        this.data = data;
    }
    
    @Override
    public void seek(long pos) throws IOException {
        if (pos < 0 || pos > data.length) {
            throw new IOException("Seek position out of bounds: " + pos);
        }
        inputStream.reset();
        inputStream.skip(pos);
    }
    
    @Override
    public long getPos() throws IOException {
        return data.length - inputStream.available();
    }
    
    @Override
    public boolean seekToNewSource(long targetPos) throws IOException {
        seek(targetPos);
        return true;
    }
    
    @Override
    public int read(long position, byte[] buffer, int offset, int length) throws IOException {
        if (position < 0 || position >= data.length) {
            return -1;
        }
        
        int available = (int) (data.length - position);
        int toRead = Math.min(length, available);
        
        System.arraycopy(data, (int) position, buffer, offset, toRead);
        
        return toRead;
    }
    
    @Override
    public void readFully(long position, byte[] buffer, int offset, int length) throws IOException {
        int bytesRead = read(position, buffer, offset, length);
        if (bytesRead < length) {
            throw new IOException("Reached end of stream");
        }
    }
    
    @Override
    public void readFully(long position, byte[] buffer) throws IOException {
        readFully(position, buffer, 0, buffer.length);
    }
    
    /**
     * Get the total size of the data
     * 
     * @return The size in bytes
     */
    public int getSize() {
        return data.length;
    }
}
