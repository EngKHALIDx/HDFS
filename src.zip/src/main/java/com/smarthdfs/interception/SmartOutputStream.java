package com.smarthdfs.interception;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * SmartOutputStream - A buffered output stream that collects data
 * and delegates to the InterceptionModule on close.
 * 
 * This stream accumulates data in memory and only decides whether
 * to aggregate or write directly when the stream is closed and
 * the total size is known.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class SmartOutputStream extends OutputStream {
    
    private final String fileName;
    private final InterceptionModule interceptionModule;
    private final ByteArrayOutputStream buffer;
    private boolean closed;
    
    /**
     * Constructor for SmartOutputStream
     * 
     * @param fileName The file name being written
     * @param interceptionModule The interception module to delegate to
     */
    public SmartOutputStream(String fileName, InterceptionModule interceptionModule) {
        this.fileName = fileName;
        this.interceptionModule = interceptionModule;
        this.buffer = new ByteArrayOutputStream();
        this.closed = false;
    }
    
    @Override
    public void write(int b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        buffer.write(b);
    }
    
    @Override
    public void write(byte[] b) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        buffer.write(b);
    }
    
    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (closed) {
            throw new IOException("Stream is closed");
        }
        buffer.write(b, off, len);
    }
    
    @Override
    public void flush() throws IOException {
        // No-op - we buffer everything until close
    }
    
    @Override
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        closed = true;
        
        // Get the buffered data
        byte[] data = buffer.toByteArray();
        
        // Delegate to interception module
        interceptionModule.handleWrite(fileName, data);
        
        // Release buffer
        buffer.reset();
    }
    
    /**
     * Get the current buffer size
     * 
     * @return The number of bytes currently buffered
     */
    public int getBufferSize() {
        return buffer.size();
    }
    
    /**
     * Get the file name
     * 
     * @return The file name
     */
    public String getFileName() {
        return fileName;
    }
    
    /**
     * Check if the stream is closed
     * 
     * @return true if closed
     */
    public boolean isClosed() {
        return closed;
    }
}
