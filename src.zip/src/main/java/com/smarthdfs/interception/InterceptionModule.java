package com.smarthdfs.interception;

import com.smarthdfs.aggregator.DynamicAggregator;
import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.index.IndexEntry;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Interception Module - Intercepts HDFS write/read operations and redirects
 * small files through the aggregation system.
 * 
 * This module implements the transparent interception pattern, allowing
 * applications to continue using standard HDFS API calls while the
 * Smart HDFS Client handles small files automatically.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class InterceptionModule {
    
    private static final Logger LOG = LoggerFactory.getLogger(InterceptionModule.class);
    
    private final SmartHdfsConfig config;
    private final FileSystem fileSystem;
    private final DynamicAggregator aggregator;
    
    // Statistics tracking
    private final AtomicBoolean initialized;
    private long totalInterceptedWrites;
    private long totalDirectWrites;
    private long totalInterceptedReads;
    
    /**
     * Constructor for InterceptionModule
     * 
     * @param config The configuration
     * @param fileSystem The underlying HDFS filesystem
     * @param aggregator The dynamic aggregator
     */
    public InterceptionModule(SmartHdfsConfig config, FileSystem fileSystem, 
                             DynamicAggregator aggregator) {
        this.config = config;
        this.fileSystem = fileSystem;
        this.aggregator = aggregator;
        
        this.initialized = new AtomicBoolean(false);
        this.totalInterceptedWrites = 0;
        this.totalDirectWrites = 0;
        this.totalInterceptedReads = 0;
        
        LOG.info("InterceptionModule created in {} mode", 
                config.isTransparentMode() ? "transparent" : "standard");
    }
    
    /**
     * Initialize the interception module
     */
    public void initialize() {
        if (initialized.compareAndSet(false, true)) {
            LOG.info("InterceptionModule initialized");
        }
    }
    
    /**
     * Intercept a file creation operation.
     * Returns a SmartOutputStream that handles small file aggregation.
     * 
     * @param path The file path
     * @param overwrite Whether to overwrite existing file
     * @return An output stream for writing
     * @throws IOException If an I/O error occurs
     */
    public OutputStream interceptCreate(Path path, boolean overwrite) throws IOException {
        if (!config.isTransparentMode()) {
            // Direct write mode
            totalDirectWrites++;
            return fileSystem.create(path, overwrite);
        }
        
        // Create a smart output stream that buffers data
        totalInterceptedWrites++;
        return new SmartOutputStream(path.toString(), this);
    }
    
    /**
     * Handle the actual write operation for a file.
     * Called by SmartOutputStream when it's closed.
     * 
     * @param fileName The file name
     * @param data The file data
     * @throws IOException If an I/O error occurs
     */
    void handleWrite(String fileName, byte[] data) throws IOException {
        // Check if file is small enough for aggregation
        if (data.length < config.getSmallFileThreshold()) {
            LOG.debug("Intercepted small file write: {} ({} bytes)", fileName, data.length);
            
            // Add to aggregator
            IndexEntry entry = aggregator.addFile(fileName, data);
            
            if (entry == null) {
                // File was too large even after check, write directly
                writeDirectly(fileName, data);
            }
        } else {
            LOG.debug("File {} is large ({} bytes), writing directly", fileName, data.length);
            writeDirectly(fileName, data);
            totalDirectWrites++;
        }
    }
    
    /**
     * Write a file directly to HDFS bypassing the aggregation system
     * 
     * @param fileName The file name
     * @param data The file data
     * @throws IOException If an I/O error occurs
     */
    private void writeDirectly(String fileName, byte[] data) throws IOException {
        Path path = new Path(fileName);
        try (FSDataOutputStream out = fileSystem.create(path, true)) {
            out.write(data);
        }
        LOG.debug("Wrote file directly: {}", fileName);
    }
    
    /**
     * Intercept a file open/read operation.
     * Checks the index first to see if the file is in a container.
     * 
     * @param path The file path
     * @return An input stream for reading
     * @throws IOException If an I/O error occurs
     */
    public FSDataInputStream interceptOpen(Path path) throws IOException {
        if (!config.isTransparentMode()) {
            return fileSystem.open(path);
        }
        
        totalInterceptedReads++;
        
        // Check if file exists in aggregator buffer or container
        byte[] data = aggregator.getFile(path.toString());
        
        if (data != null) {
            LOG.debug("Reading file {} from container/buffer", path);
            return new ByteArrayFSDataInputStream(data);
        }
        
        // File not in aggregation system, read directly
        LOG.debug("Reading file {} directly from HDFS", path);
        return fileSystem.open(path);
    }
    
    /**
     * Check if a file exists, checking both HDFS and aggregated files
     * 
     * @param path The file path
     * @return true if the file exists
     * @throws IOException If an I/O error occurs
     */
    public boolean exists(Path path) throws IOException {
        // Check aggregator first
        if (aggregator.getFile(path.toString()) != null) {
            return true;
        }
        
        // Check HDFS
        return fileSystem.exists(path);
    }
    
    /**
     * Delete a file, handling both HDFS and aggregated files
     * 
     * @param path The file path
     * @param recursive Whether to delete recursively
     * @return true if deletion succeeded
     * @throws IOException If an I/O error occurs
     */
    public boolean delete(Path path, boolean recursive) throws IOException {
        // For aggregated files, we just mark them as deleted in the index
        // Actual deletion from containers would require compaction
        
        // Try to delete from HDFS
        if (fileSystem.exists(path)) {
            return fileSystem.delete(path, recursive);
        }
        
        // File might be in buffer or container
        // For now, we just return true (soft delete)
        LOG.warn("Delete called for potentially aggregated file: {}", path);
        return true;
    }
    
    /**
     * Get statistics for the interception module
     * 
     * @return Map of statistics
     */
    public java.util.Map<String, Long> getStatistics() {
        java.util.Map<String, Long> stats = new java.util.concurrent.ConcurrentHashMap<>();
        stats.put("interceptedWrites", totalInterceptedWrites);
        stats.put("directWrites", totalDirectWrites);
        stats.put("interceptedReads", totalInterceptedReads);
        stats.put("aggregationRatio", 
                totalInterceptedWrites + totalDirectWrites > 0 ?
                (totalInterceptedWrites * 100) / (totalInterceptedWrites + totalDirectWrites) : 0);
        return stats;
    }
    
    /**
     * Shutdown the interception module
     * 
     * @throws IOException If an I/O error occurs
     */
    public void shutdown() throws IOException {
        if (initialized.compareAndSet(true, false)) {
            LOG.info("Shutting down InterceptionModule");
            LOG.info("Statistics: {}", getStatistics());
        }
    }
}
