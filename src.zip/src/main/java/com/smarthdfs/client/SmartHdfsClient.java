package com.smarthdfs.client;

import com.smarthdfs.aggregator.DynamicAggregator;
import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.index.IndexManager;
import com.smarthdfs.interception.InterceptionModule;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.ContentSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.util.Map;

/**
 * SmartHdfsClient - Transparent HDFS Client with Small File Aggregation
 * 
 * <p>This class provides a transparent wrapper around the standard HDFS FileSystem
 * from Apache Hadoop (https://github.com/apache/hadoop/).
 * 
 * <h2>Apache Hadoop Integration</h2>
 * <p>Uses real Hadoop classes:
 * <ul>
 *   <li>{@link org.apache.hadoop.fs.FileSystem} - Main HDFS client</li>
 *   <li>{@link org.apache.hadoop.fs.Path} - HDFS path representation</li>
 *   <li>{@link org.apache.hadoop.fs.FSDataInputStream} - Input stream</li>
 *   <li>{@link org.apache.hadoop.fs.FSDataOutputStream} - Output stream</li>
 *   <li>{@link org.apache.hadoop.io.SequenceFile} - Container format</li>
 *   <li>{@link org.apache.hadoop.conf.Configuration} - Hadoop configuration</li>
 * </ul>
 * 
 * <h2>Usage Example</h2>
 * <pre>
 * // Create configuration
 * SmartHdfsConfig config = SmartHdfsConfig.builder()
 *     .smallFileThreshold(128 * 1024 * 1024)  // 128 MB
 *     .bufferSize(64 * 1024 * 1024)            // 64 MB
 *     .enableAutoFlush(true)
 *     .build();
 * 
 * // Create client - connects to real HDFS
 * SmartHdfsClient client = SmartHdfsClient.create(config, "hdfs://namenode:9000");
 * 
 * // Write files - transparent aggregation
 * OutputStream out = client.create(new Path("/data/file.txt"));
 * out.write(data);
 * out.close();
 * 
 * // Read files - transparent retrieval
 * FSDataInputStream in = client.open(new Path("/data/file.txt"));
 * 
 * // Close
 * client.close();
 * </pre>
 * 
 * @author Khaled Abdullah Mohammed Hussein Al-Kholani
 * @author Sana'a University
 * @version 1.0.0
 * @see <a href="https://github.com/apache/hadoop/">Apache Hadoop GitHub</a>
 * @see org.apache.hadoop.fs.FileSystem
 */
public class SmartHdfsClient {
    
    private static final Logger LOG = LoggerFactory.getLogger(SmartHdfsClient.class);
    
    private final SmartHdfsConfig config;
    private final FileSystem fileSystem;
    private final IndexManager indexManager;
    private final DynamicAggregator aggregator;
    private final InterceptionModule interceptionModule;
    
    private boolean closed;
    
    /**
     * Private constructor - use factory methods
     */
    private SmartHdfsClient(SmartHdfsConfig config, FileSystem fileSystem,
                           IndexManager indexManager, DynamicAggregator aggregator,
                           InterceptionModule interceptionModule) {
        this.config = config;
        this.fileSystem = fileSystem;
        this.indexManager = indexManager;
        this.aggregator = aggregator;
        this.interceptionModule = interceptionModule;
        this.closed = false;
    }
    
    /**
     * Create a SmartHdfsClient with default configuration.
     * 
     * <p>Uses Apache Hadoop's FileSystem.get() to connect to HDFS.
     * 
     * @param hdfsUri The HDFS URI (e.g., "hdfs://namenode:9000")
     * @return The created SmartHdfsClient
     * @throws IOException If creation fails
     * @see FileSystem#get(URI, Configuration)
     */
    public static SmartHdfsClient create(String hdfsUri) throws IOException {
        return create(new SmartHdfsConfig(), hdfsUri);
    }
    
    /**
     * Create a SmartHdfsClient with custom configuration.
     * 
     * <p>Uses Apache Hadoop's Configuration and FileSystem classes.
     * 
     * @param config The SmartHdfsConfig
     * @param hdfsUri The HDFS URI
     * @return The created SmartHdfsClient
     * @throws IOException If creation fails
     * @see Configuration
     * @see FileSystem
     */
    public static SmartHdfsClient create(SmartHdfsConfig config, String hdfsUri) throws IOException {
        return create(config, hdfsUri, new Configuration());
    }
    
    /**
     * Create a SmartHdfsClient with custom Hadoop configuration.
     * 
     * <p>This method initializes the connection to HDFS using Apache Hadoop's
     * standard FileSystem API. All underlying operations use real Hadoop classes.
     * 
     * @param config The Smart HDFS configuration
     * @param hdfsUri The HDFS URI (from core-site.xml fs.defaultFS)
     * @param hadoopConf The Hadoop Configuration (loaded from Hadoop config files)
     * @return The created SmartHdfsClient
     * @throws IOException If creation fails
     * @see Configuration
     * @see FileSystem#get(URI, Configuration)
     */
    public static SmartHdfsClient create(SmartHdfsConfig config, String hdfsUri, 
                                         Configuration hadoopConf) throws IOException {
        LOG.info("Creating SmartHdfsClient for URI: {}", hdfsUri);
        LOG.info("Using Apache Hadoop from: https://github.com/apache/hadoop/");
        LOG.info("Hadoop Configuration: {}", hadoopConf);
        LOG.info("Smart HDFS Configuration: {}", config);
        
        // Initialize FileSystem using Apache Hadoop API
        // This is the real HDFS client from hadoop-hdfs-client
        FileSystem fileSystem = FileSystem.get(URI.create(hdfsUri), hadoopConf);
        LOG.info("Connected to HDFS: {}", fileSystem.getUri());
        LOG.info("HDFS Working Directory: {}", fileSystem.getWorkingDirectory());
        
        // Initialize IndexManager
        IndexManager indexManager = new IndexManager(config, fileSystem);
        
        // Initialize DynamicAggregator
        DynamicAggregator aggregator = new DynamicAggregator(config, fileSystem, indexManager);
        
        // Initialize InterceptionModule
        InterceptionModule interceptionModule = new InterceptionModule(config, fileSystem, aggregator);
        interceptionModule.initialize();
        
        return new SmartHdfsClient(config, fileSystem, indexManager, aggregator, interceptionModule);
    }
    
    /**
     * Create a file for writing.
     * 
     * <p>Small files will be automatically aggregated into SequenceFile containers.
     * Large files will be written directly to HDFS.
     * 
     * @param path The file path (Hadoop Path object)
     * @return An output stream for writing
     * @throws IOException If an I/O error occurs
     * @see org.apache.hadoop.fs.FileSystem#create(Path)
     */
    public OutputStream create(Path path) throws IOException {
        return create(path, true);
    }
    
    /**
     * Create a file for writing with overwrite option.
     * 
     * @param path The file path
     * @param overwrite Whether to overwrite existing file
     * @return An output stream for writing
     * @throws IOException If an I/O error occurs
     */
    public OutputStream create(Path path, boolean overwrite) throws IOException {
        checkNotClosed();
        return interceptionModule.interceptCreate(path, overwrite);
    }
    
    /**
     * Open a file for reading.
     * 
     * <p>Automatically handles files stored in aggregated containers.
     * Uses the side-car index to locate files.
     * 
     * @param path The file path
     * @return An FSDataInputStream for reading
     * @throws IOException If an I/O error occurs
     * @see org.apache.hadoop.fs.FileSystem#open(Path)
     */
    public FSDataInputStream open(Path path) throws IOException {
        checkNotClosed();
        return interceptionModule.interceptOpen(path);
    }
    
    /**
     * Check if a file exists.
     * 
     * @param path The file path
     * @return true if the file exists
     * @throws IOException If an I/O error occurs
     * @see FileSystem#exists(Path)
     */
    public boolean exists(Path path) throws IOException {
        checkNotClosed();
        return interceptionModule.exists(path);
    }
    
    /**
     * Delete a file or directory.
     * 
     * @param path The path to delete
     * @param recursive Whether to delete recursively
     * @return true if deletion succeeded
     * @throws IOException If an I/O error occurs
     * @see FileSystem#delete(Path, boolean)
     */
    public boolean delete(Path path, boolean recursive) throws IOException {
        checkNotClosed();
        return interceptionModule.delete(path, recursive);
    }
    
    /**
     * Create a directory.
     * 
     * @param path The directory path
     * @return true if successful
     * @throws IOException If an I/O error occurs
     * @see FileSystem#mkdirs(Path)
     */
    public boolean mkdirs(Path path) throws IOException {
        checkNotClosed();
        return fileSystem.mkdirs(path);
    }
    
    /**
     * List files in a directory.
     * 
     * @param path The directory path
     * @return Array of FileStatus
     * @throws IOException If an I/O error occurs
     * @see FileSystem#listStatus(Path)
     */
    public FileStatus[] listStatus(Path path) throws IOException {
        checkNotClosed();
        return fileSystem.listStatus(path);
    }
    
    /**
     * Get file status.
     * 
     * @param path The file path
     * @return FileStatus
     * @throws IOException If an I/O error occurs
     * @see FileSystem#getFileStatus(Path)
     */
    public FileStatus getFileStatus(Path path) throws IOException {
        checkNotClosed();
        return fileSystem.getFileStatus(path);
    }
    
    /**
     * Get content summary of a directory.
     * 
     * @param path The directory path
     * @return ContentSummary
     * @throws IOException If an I/O error occurs
     * @see FileSystem#getContentSummary(Path)
     */
    public ContentSummary getContentSummary(Path path) throws IOException {
        checkNotClosed();
        return fileSystem.getContentSummary(path);
    }
    
    /**
     * Rename a file or directory.
     * 
     * @param src Source path
     * @param dst Destination path
     * @return true if successful
     * @throws IOException If an I/O error occurs
     * @see FileSystem#rename(Path, Path)
     */
    public boolean rename(Path src, Path dst) throws IOException {
        checkNotClosed();
        return fileSystem.rename(src, dst);
    }
    
    /**
     * Set working directory.
     * 
     * @param path The new working directory
     * @see FileSystem#setWorkingDirectory(Path)
     */
    public void setWorkingDirectory(Path path) {
        fileSystem.setWorkingDirectory(path);
    }
    
    /**
     * Get working directory.
     * 
     * @return Current working directory
     * @see FileSystem#getWorkingDirectory()
     */
    public Path getWorkingDirectory() {
        return fileSystem.getWorkingDirectory();
    }
    
    /**
     * Get the underlying Hadoop FileSystem.
     * 
     * <p>Use this for advanced operations not covered by SmartHdfsClient.
     * 
     * @return The Hadoop FileSystem instance
     */
    public FileSystem getFileSystem() {
        return fileSystem;
    }
    
    /**
     * Get the Hadoop Configuration.
     * 
     * @return The Configuration
     */
    public Configuration getConfiguration() {
        return fileSystem.getConf();
    }
    
    /**
     * Get the Smart HDFS configuration.
     * 
     * @return The SmartHdfsConfig
     */
    public SmartHdfsConfig getConfig() {
        return config;
    }
    
    /**
     * Get the HDFS URI.
     * 
     * @return The HDFS URI
     */
    public URI getUri() {
        return fileSystem.getUri();
    }
    
    /**
     * Force flush all buffered files.
     * 
     * @throws IOException If an I/O error occurs
     */
    public void flush() throws IOException {
        checkNotClosed();
        aggregator.forceFlush();
    }
    
    /**
     * Get comprehensive statistics.
     * 
     * @return Map of statistics
     */
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new java.util.concurrent.ConcurrentHashMap<>();
        
        stats.put("hdfsUri", fileSystem.getUri().toString());
        stats.put("aggregator", aggregator.getStatistics());
        stats.put("index", indexManager.getStatistics());
        stats.put("interception", interceptionModule.getStatistics());
        
        return stats;
    }
    
    /**
     * Print statistics to the log.
     */
    public void logStatistics() {
        LOG.info("=== Smart HDFS Client Statistics ===");
        LOG.info("HDFS URI: {}", fileSystem.getUri());
        LOG.info("Aggregator: {}", aggregator.getStatistics());
        LOG.info("Index: {}", indexManager.getStatistics());
        LOG.info("Interception: {}", interceptionModule.getStatistics());
    }
    
    /**
     * Close the client and release resources.
     * 
     * <p>This method:
     * <ol>
     *   <li>Flushes remaining buffered files</li>
     *   <li>Persists the index</li>
     *   <li>Closes the underlying Hadoop FileSystem</li>
     * </ol>
     * 
     * @throws IOException If an I/O error occurs
     * @see FileSystem#close()
     */
    public void close() throws IOException {
        if (closed) {
            return;
        }
        
        LOG.info("Closing SmartHdfsClient...");
        
        try {
            // Log final statistics
            logStatistics();
            
            // Flush any remaining files
            if (aggregator.getCurrentBufferSize() > 0) {
                LOG.info("Flushing remaining {} bytes before close", aggregator.getCurrentBufferSize());
                aggregator.forceFlush();
            }
            
            // Shutdown components in reverse order
            interceptionModule.shutdown();
            aggregator.shutdown();
            
            // Persist index
            indexManager.persistMasterIndex();
            
            // Close filesystem (Hadoop API)
            fileSystem.close();
            
            closed = true;
            LOG.info("SmartHdfsClient closed successfully");
            
        } catch (Exception e) {
            LOG.error("Error closing SmartHdfsClient", e);
            throw new IOException("Failed to close SmartHdfsClient", e);
        }
    }
    
    /**
     * Check if the client is closed.
     * 
     * @return true if closed
     */
    public boolean isClosed() {
        return closed;
    }
    
    /**
     * Check that the client is not closed.
     * 
     * @throws IOException If the client is closed
     */
    private void checkNotClosed() throws IOException {
        if (closed) {
            throw new IOException("SmartHdfsClient is closed");
        }
    }
}
