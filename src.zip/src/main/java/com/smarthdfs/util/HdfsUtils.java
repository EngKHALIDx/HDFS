package com.smarthdfs.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;

/**
 * Utility class for common operations in the Smart HDFS Client Library.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public final class HdfsUtils {
    
    private static final Logger LOG = LoggerFactory.getLogger(HdfsUtils.class);
    
    private static final DecimalFormat SIZE_FORMAT = new DecimalFormat("#,##0.##");
    
    private static final String[] SIZE_UNITS = {"B", "KB", "MB", "GB", "TB", "PB"};
    
    // Private constructor to prevent instantiation
    private HdfsUtils() {
    }
    
    /**
     * Format a byte size to human-readable format
     * 
     * @param bytes The size in bytes
     * @return Formatted string (e.g., "1.5 GB")
     */
    public static String formatSize(long bytes) {
        if (bytes < 0) {
            return "N/A";
        }
        
        if (bytes < 1024) {
            return bytes + " B";
        }
        
        int unitIndex = 0;
        double size = bytes;
        
        while (size >= 1024 && unitIndex < SIZE_UNITS.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return String.format("%.2f %s", size, SIZE_UNITS[unitIndex]);
    }
    
    /**
     * Calculate the reduction ratio (e.g., for memory savings)
     * 
     * @param original The original value
     * @param reduced The reduced value
     * @return The reduction percentage (0-100)
     */
    public static double calculateReductionRatio(long original, long reduced) {
        if (original == 0) {
            return 0;
        }
        return ((double) (original - reduced) / original) * 100;
    }
    
    /**
     * Estimate memory usage for a number of files in NameNode
     * 
     * Each file in HDFS NameNode uses approximately 150 bytes of memory
     * for metadata (inode information, block maps, etc.)
     * 
     * @param fileCount The number of files
     * @return Estimated memory usage in bytes
     */
    public static long estimateNameNodeMemory(long fileCount) {
        // Each file uses ~150 bytes in NameNode memory
        // This includes: inode (~80 bytes) + block info (~70 bytes)
        return fileCount * 150;
    }
    
    /**
     * Calculate the number of files that can be aggregated into containers
     * 
     * @param totalFiles Total number of small files
     * @param containerSize Target container size in bytes
     * @param avgFileSize Average file size in bytes
     * @return Estimated number of container files
     */
    public static int estimateContainerCount(long totalFiles, long containerSize, long avgFileSize) {
        if (avgFileSize <= 0) {
            return 0;
        }
        
        long totalDataSize = totalFiles * avgFileSize;
        return (int) Math.ceil((double) totalDataSize / containerSize);
    }
    
    /**
     * Calculate memory savings from aggregation
     * 
     * @param originalFiles Number of original files
     * @param containerFiles Number of container files
     * @return Memory savings in bytes
     */
    public static long calculateMemorySavings(long originalFiles, long containerFiles) {
        long originalMemory = estimateNameNodeMemory(originalFiles);
        long containerMemory = estimateNameNodeMemory(containerFiles);
        return originalMemory - containerMemory;
    }
    
    /**
     * Validate a file path
     * 
     * @param path The path to validate
     * @return true if valid
     */
    public static boolean isValidPath(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }
        
        // Check for invalid characters
        // HDFS paths should not contain certain characters
        String invalidChars = "<>:\"|?*";
        for (char c : invalidChars.toCharArray()) {
            if (path.indexOf(c) >= 0) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Extract file name from full path
     * 
     * @param path The full path
     * @return The file name
     */
    public static String extractFileName(String path) {
        if (path == null || path.isEmpty()) {
            return "";
        }
        
        // Handle both Unix and Windows path separators
        int lastSeparator = Math.max(
                path.lastIndexOf('/'),
                path.lastIndexOf('\\')
        );
        
        return lastSeparator >= 0 ? path.substring(lastSeparator + 1) : path;
    }
    
    /**
     * Extract directory path from full path
     * 
     * @param path The full path
     * @return The directory path
     */
    public static String extractDirectory(String path) {
        if (path == null || path.isEmpty()) {
            return "";
        }
        
        // Handle both Unix and Windows path separators
        int lastSeparator = Math.max(
                path.lastIndexOf('/'),
                path.lastIndexOf('\\')
        );
        
        return lastSeparator >= 0 ? path.substring(0, lastSeparator) : "";
    }
    
    /**
     * Generate a unique file name with timestamp
     * 
     * @param prefix The prefix
     * @param suffix The suffix (extension)
     * @return A unique file name
     */
    public static String generateUniqueFileName(String prefix, String suffix) {
        long timestamp = System.currentTimeMillis();
        long random = (long) (Math.random() * 10000);
        
        StringBuilder sb = new StringBuilder();
        if (prefix != null && !prefix.isEmpty()) {
            sb.append(prefix);
            if (!prefix.endsWith("_") && !prefix.endsWith("-")) {
                sb.append("_");
            }
        }
        sb.append(timestamp);
        sb.append("_");
        sb.append(String.format("%04d", random));
        
        if (suffix != null && !suffix.isEmpty()) {
            if (!suffix.startsWith(".")) {
                sb.append(".");
            }
            sb.append(suffix);
        }
        
        return sb.toString();
    }
    
    /**
     * Sleep without throwing checked exception
     * 
     * @param millis The time to sleep in milliseconds
     */
    public static void sleepQuietly(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            LOG.warn("Sleep interrupted", e);
        }
    }
    
    /**
     * Calculate throughput (bytes per second)
     * 
     * @param bytes The number of bytes
     * @param durationMs The duration in milliseconds
     * @return Throughput in bytes per second
     */
    public static double calculateThroughput(long bytes, long durationMs) {
        if (durationMs <= 0) {
            return 0;
        }
        return (bytes * 1000.0) / durationMs;
    }
    
    /**
     * Format throughput for display
     * 
     * @param bytesPerSecond The throughput in bytes per second
     * @return Formatted string (e.g., "150.5 MB/s")
     */
    public static String formatThroughput(double bytesPerSecond) {
        return formatSize((long) bytesPerSecond) + "/s";
    }
}
