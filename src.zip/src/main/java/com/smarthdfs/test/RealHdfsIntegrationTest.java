package com.smarthdfs.test;

import com.smarthdfs.client.SmartHdfsClient;
import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.OutputStream;
import java.net.URI;
import java.util.Random;

/**
 * Real HDFS Integration Test - Tests Smart HDFS Client against real HDFS cluster.
 * 
 * Prerequisites:
 * 1. HDFS cluster running (use: docker-compose up -d)
 * 2. NameNode accessible at hdfs://localhost:9000
 * 
 * @author Khaled Abdullah Mohammed Hussein Al-Kholani - Sana'a University
 */
public class RealHdfsIntegrationTest {
    
    private static final String HDFS_URI = "hdfs://localhost:9000";
    private static final String TEST_DIR = "/smart-hdfs-test-" + System.currentTimeMillis();
    
    public static void main(String[] args) throws Exception {
        String hdfsUri = args.length > 0 ? args[0] : HDFS_URI;
        
        System.out.println("\n╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║        Smart HDFS Client - Real HDFS Integration Test            ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝\n");
        System.out.println("Testing against: " + hdfsUri + "\n");
        
        // Test 1: Connection
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println("Test 1: HDFS Connection Test");
        System.out.println("══════════════════════════════════════════════════════════════════");
        
        if (testConnection(hdfsUri)) {
            System.out.println("✅ HDFS Connection: SUCCESS\n");
        } else {
            System.out.println("❌ HDFS Connection: FAILED");
            System.out.println("Please ensure HDFS is running: docker-compose up -d");
            return;
        }
        
        // Test 2: Standard HDFS
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println("Test 2: Standard HDFS Read/Write");
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println(testStandardHdfs(hdfsUri) ? "✅ Standard HDFS: SUCCESS\n" : "❌ Standard HDFS: FAILED\n");
        
        // Test 3: Smart HDFS Client
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println("Test 3: Smart HDFS Client Read/Write");
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println(testSmartHdfs(hdfsUri) ? "✅ Smart HDFS Client: SUCCESS\n" : "❌ Smart HDFS Client: FAILED\n");
        
        // Test 4: Performance
        System.out.println("══════════════════════════════════════════════════════════════════");
        System.out.println("Test 4: Performance Comparison");
        System.out.println("══════════════════════════════════════════════════════════════════");
        runPerformanceComparison(hdfsUri);
        
        // Cleanup
        cleanup(hdfsUri);
        System.out.println("\n╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║                    All Tests Complete!                           ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝");
    }
    
    private static boolean testConnection(String hdfsUri) {
        try {
            Configuration config = new Configuration();
            config.set("fs.defaultFS", hdfsUri);
            config.set("dfs.client.use.datanode.hostname", "true");
            FileSystem fs = FileSystem.get(URI.create(hdfsUri), config);
            fs.listStatus(new Path("/"));
            fs.close();
            return true;
        } catch (Exception e) {
            System.out.println("Connection error: " + e.getMessage());
            return false;
        }
    }
    
    private static boolean testStandardHdfs(String hdfsUri) {
        try {
            Configuration config = new Configuration();
            config.set("fs.defaultFS", hdfsUri);
            config.set("dfs.client.use.datanode.hostname", "true");
            FileSystem fs = FileSystem.get(URI.create(hdfsUri), config);
            
            Path testPath = new Path(TEST_DIR + "/standard");
            fs.mkdirs(testPath);
            
            byte[] data = "Hello Standard HDFS!".getBytes();
            Path filePath = new Path(testPath, "test.txt");
            
            try (OutputStream out = fs.create(filePath)) {
                out.write(data);
            }
            
            try (FSDataInputStream in = fs.open(filePath)) {
                byte[] readData = new byte[data.length];
                in.readFully(readData);
                if (!java.util.Arrays.equals(data, readData)) return false;
            }
            
            fs.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
    
    private static boolean testSmartHdfs(String hdfsUri) {
        try {
            SmartHdfsConfig config = SmartHdfsConfig.builder()
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)
                .enableAutoFlush(true)
                .containerDir(TEST_DIR + "/containers")
                .build();
            
            Configuration hadoopConfig = new Configuration();
            hadoopConfig.set("fs.defaultFS", hdfsUri);
            hadoopConfig.set("dfs.client.use.datanode.hostname", "true");
            
            SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, hadoopConfig);
            
            Path testPath = new Path(TEST_DIR + "/smart");
            client.mkdirs(testPath);
            
            byte[] data = "Hello Smart HDFS Client!".getBytes();
            Path filePath = new Path(testPath, "test.txt");
            
            try (OutputStream out = client.create(filePath)) {
                out.write(data);
            }
            
            client.flush();
            
            try (FSDataInputStream in = client.open(filePath)) {
                byte[] readData = new byte[data.length];
                in.readFully(readData);
                if (!java.util.Arrays.equals(data, readData)) return false;
            }
            
            client.close();
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private static void runPerformanceComparison(String hdfsUri) throws Exception {
        int fileCount = 100;
        int fileSize = 50 * 1024;
        
        Random random = new Random(42);
        byte[][] testData = new byte[fileCount][];
        for (int i = 0; i < fileCount; i++) {
            testData[i] = new byte[fileSize];
            random.nextBytes(testData[i]);
        }
        
        Configuration hadoopConfig = new Configuration();
        hadoopConfig.set("fs.defaultFS", hdfsUri);
        hadoopConfig.set("dfs.client.use.datanode.hostname", "true");
        
        // Standard HDFS
        FileSystem fs = FileSystem.get(URI.create(hdfsUri), hadoopConfig);
        Path standardDir = new Path(TEST_DIR + "/perf-standard");
        fs.mkdirs(standardDir);
        
        long stdStart = System.currentTimeMillis();
        for (int i = 0; i < fileCount; i++) {
            try (OutputStream out = fs.create(new Path(standardDir, "file_" + i + ".dat"))) {
                out.write(testData[i]);
            }
        }
        long stdTime = System.currentTimeMillis() - stdStart;
        fs.delete(standardDir, true);
        fs.close();
        
        System.out.println("Standard HDFS Write: " + stdTime + " ms");
        
        // Smart HDFS Client
        SmartHdfsConfig smartConfig = SmartHdfsConfig.builder()
            .smallFileThreshold(128 * 1024 * 1024)
            .bufferSize(64 * 1024 * 1024)
            .enableAutoFlush(true)
            .containerDir(TEST_DIR + "/perf-containers")
            .build();
        
        SmartHdfsClient smartClient = SmartHdfsClient.create(smartConfig, hdfsUri, hadoopConfig);
        Path smartDir = new Path(TEST_DIR + "/perf-smart");
        smartClient.mkdirs(smartDir);
        
        long smartStart = System.currentTimeMillis();
        for (int i = 0; i < fileCount; i++) {
            try (OutputStream out = smartClient.create(new Path(smartDir, "file_" + i + ".dat"))) {
                out.write(testData[i]);
            }
        }
        smartClient.flush();
        long smartTime = System.currentTimeMillis() - smartStart;
        smartClient.close();
        
        System.out.println("Smart HDFS Write: " + smartTime + " ms");
        
        double improvement = ((stdTime - smartTime) / (double) stdTime) * 100;
        System.out.println("\nImprovement: " + String.format("%.1f%%", improvement));
    }
    
    private static void cleanup(String hdfsUri) throws Exception {
        Configuration config = new Configuration();
        config.set("fs.defaultFS", hdfsUri);
        config.set("dfs.client.use.datanode.hostname", "true");
        FileSystem fs = FileSystem.get(URI.create(hdfsUri), config);
        fs.delete(new Path(TEST_DIR), true);
        fs.close();
    }
}
