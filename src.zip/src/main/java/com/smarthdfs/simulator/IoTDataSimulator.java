package com.smarthdfs.simulator;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Random;
import java.util.UUID;

/**
 * IoT Data Simulator - Generates realistic IoT sensor data for testing.
 * 
 * This class simulates various types of IoT devices and generates
 * small JSON data files that represent typical IoT workloads.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class IoTDataSimulator {
    
    private final Random random;
    private final String[] deviceTypes;
    private final String[] locations;
    private final String[] sensorTypes;
    
    /**
     * Constructor for IoTDataSimulator
     */
    public IoTDataSimulator() {
        this.random = new Random();
        this.deviceTypes = new String[]{
            "temperature_sensor",
            "humidity_sensor",
            "pressure_sensor",
            "motion_detector",
            "light_sensor",
            "air_quality_monitor",
            "water_level_sensor",
            "vibration_sensor"
        };
        this.locations = new String[]{
            "building_a_floor_1",
            "building_a_floor_2",
            "building_b_floor_1",
            "warehouse_zone_1",
            "warehouse_zone_2",
            "outdoor_garden",
            "parking_lot",
            "server_room"
        };
        this.sensorTypes = new String[]{
            "dht22", "bmp280", "mpu6050", "hc_sr501", "mq135", "hcsr04"
        };
    }
    
    /**
     * Generate a single IoT sensor reading as JSON
     * 
     * @param deviceId The device ID
     * @return JSON string representing the sensor reading
     */
    public String generateSensorReading(String deviceId) {
        String deviceType = deviceTypes[random.nextInt(deviceTypes.length)];
        String location = locations[random.nextInt(locations.length)];
        String sensorType = sensorTypes[random.nextInt(sensorTypes.length)];
        
        double value = generateSensorValue(deviceType);
        String unit = getUnitForSensorType(deviceType);
        String status = value > 0 ? "normal" : "warning";
        
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"device_id\":\"").append(deviceId).append("\",");
        json.append("\"device_type\":\"").append(deviceType).append("\",");
        json.append("\"location\":\"").append(location).append("\",");
        json.append("\"sensor_type\":\"").append(sensorType).append("\",");
        json.append("\"value\":").append(String.format("%.2f", value)).append(",");
        json.append("\"unit\":\"").append(unit).append("\",");
        json.append("\"status\":\"").append(status).append("\",");
        json.append("\"timestamp\":\"").append(Instant.now().toString()).append("\",");
        json.append("\"metadata\":{");
        json.append("\"firmware_version\":\"2.1.3\",");
        json.append("\"battery_level\":").append(random.nextInt(100)).append(",");
        json.append("\"signal_strength\":").append(-30 - random.nextInt(60));
        json.append("}");
        json.append("}");
        
        return json.toString();
    }
    
    /**
     * Generate sensor value based on device type
     */
    private double generateSensorValue(String deviceType) {
        switch (deviceType) {
            case "temperature_sensor":
                return 15 + random.nextDouble() * 30; // 15-45°C
            case "humidity_sensor":
                return 20 + random.nextDouble() * 60; // 20-80%
            case "pressure_sensor":
                return 990 + random.nextDouble() * 40; // 990-1030 hPa
            case "motion_detector":
                return random.nextDouble() < 0.3 ? 1 : 0; // Binary
            case "light_sensor":
                return random.nextDouble() * 10000; // 0-10000 lux
            case "air_quality_monitor":
                return 0 + random.nextDouble() * 500; // 0-500 AQI
            case "water_level_sensor":
                return random.nextDouble() * 100; // 0-100%
            case "vibration_sensor":
                return random.nextDouble() * 100; // 0-100 Hz
            default:
                return random.nextDouble() * 100;
        }
    }
    
    /**
     * Get unit for sensor type
     */
    private String getUnitForSensorType(String deviceType) {
        switch (deviceType) {
            case "temperature_sensor": return "celsius";
            case "humidity_sensor": return "percent";
            case "pressure_sensor": return "hPa";
            case "motion_detector": return "boolean";
            case "light_sensor": return "lux";
            case "air_quality_monitor": return "AQI";
            case "water_level_sensor": return "percent";
            case "vibration_sensor": return "Hz";
            default: return "unknown";
        }
    }
    
    /**
     * Generate multiple sensor readings
     * 
     * @param count Number of readings to generate
     * @return Array of JSON strings
     */
    public String[] generateSensorReadings(int count) {
        String[] readings = new String[count];
        String baseDeviceId = "device_" + UUID.randomUUID().toString().substring(0, 8);
        
        for (int i = 0; i < count; i++) {
            String deviceId = baseDeviceId + "_" + (i % 10); // 10 devices
            readings[i] = generateSensorReading(deviceId);
        }
        
        return readings;
    }
    
    /**
     * Generate a batch of sensor data files
     * 
     * @param numFiles Number of files to generate
     * @param readingsPerFile Number of readings per file
     * @return Array of file contents (each as byte array)
     */
    public byte[][] generateDataFiles(int numFiles, int readingsPerFile) {
        byte[][] files = new byte[numFiles][];
        
        for (int i = 0; i < numFiles; i++) {
            String[] readings = generateSensorReadings(readingsPerFile);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            try {
                for (String reading : readings) {
                    baos.write(reading.getBytes(StandardCharsets.UTF_8));
                    baos.write('\n');
                }
                files[i] = baos.toByteArray();
            } catch (IOException e) {
                files[i] = new byte[0];
            }
        }
        
        return files;
    }
    
    /**
     * Generate a file name for an IoT data file
     * 
     * @param index The file index
     * @return A unique file name
     */
    public String generateFileName(int index) {
        return String.format("/iot_data/%s/sensor_data_%05d.json",
                Instant.now().toString().substring(0, 10), index);
    }
    
    /**
     * Get statistics about generated data
     * 
     * @param files The generated files
     * @return Statistics string
     */
    public String getDataStatistics(byte[][] files) {
        long totalSize = 0;
        int minSize = Integer.MAX_VALUE;
        int maxSize = Integer.MIN_VALUE;
        
        for (byte[] file : files) {
            int size = file.length;
            totalSize += size;
            minSize = Math.min(minSize, size);
            maxSize = Math.max(maxSize, size);
        }
        
        double avgSize = (double) totalSize / files.length;
        
        return String.format(
                "Data Statistics:\n" +
                "  Total Files: %d\n" +
                "  Total Size: %.2f KB\n" +
                "  Average File Size: %.2f bytes\n" +
                "  Min File Size: %d bytes\n" +
                "  Max File Size: %d bytes",
                files.length,
                totalSize / 1024.0,
                avgSize,
                minSize,
                maxSize
        );
    }
}
