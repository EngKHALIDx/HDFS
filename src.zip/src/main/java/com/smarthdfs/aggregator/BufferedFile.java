package com.smarthdfs.aggregator;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.time.Instant;

/**
 * Represents a small file entry stored in the buffer.
 * This class holds metadata and data for a single small file
 * before it is aggregated into a container file.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class BufferedFile implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private final String fileName;
    private final byte[] data;
    private final long timestamp;
    private final long size;
    private String containerName;
    private long offsetInContainer;
    private boolean isWritten;
    
    /**
     * Constructor for a buffered file entry
     * 
     * @param fileName The name/path of the file
     * @param data The file content as byte array
     */
    public BufferedFile(String fileName, byte[] data) {
        this.fileName = fileName;
        this.data = data;
        this.size = data.length;
        this.timestamp = Instant.now().toEpochMilli();
        this.isWritten = false;
        this.offsetInContainer = -1;
    }
    
    /**
     * Get the file name/path
     * @return The file name
     */
    public String getFileName() {
        return fileName;
    }
    
    /**
     * Get the file data
     * @return The file content as byte array
     */
    public byte[] getData() {
        return data;
    }
    
    /**
     * Get the file size in bytes
     * @return The file size
     */
    public long getSize() {
        return size;
    }
    
    /**
     * Get the timestamp when the file was buffered
     * @return Timestamp in milliseconds since epoch
     */
    public long getTimestamp() {
        return timestamp;
    }
    
    /**
     * Get the container name where this file is stored
     * @return The container file name
     */
    public String getContainerName() {
        return containerName;
    }
    
    /**
     * Set the container name
     * @param containerName The container file name
     */
    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }
    
    /**
     * Get the offset position in the container file
     * @return The offset in bytes
     */
    public long getOffsetInContainer() {
        return offsetInContainer;
    }
    
    /**
     * Set the offset position in the container file
     * @param offsetInContainer The offset in bytes
     */
    public void setOffsetInContainer(long offsetInContainer) {
        this.offsetInContainer = offsetInContainer;
    }
    
    /**
     * Check if the file has been written to container
     * @return true if written, false otherwise
     */
    public boolean isWritten() {
        return isWritten;
    }
    
    /**
     * Mark the file as written
     * @param written The written status
     */
    public void setWritten(boolean written) {
        isWritten = written;
    }
    
    /**
     * Create a data input stream for reading the file content
     * @return DataInputStream for the file content
     */
    public DataInputStream createInputStream() {
        return new DataInputStream(new ByteArrayInputStream(data));
    }
    
    /**
     * Write the file data to a data output stream
     * 
     * @param out The data output stream to write to
     * @throws IOException If an I/O error occurs
     */
    public void writeTo(DataOutputStream out) throws IOException {
        out.writeUTF(fileName);
        out.writeLong(timestamp);
        out.writeInt(data.length);
        out.write(data);
    }
    
    /**
     * Read a buffered file from a data input stream
     * 
     * @param in The data input stream to read from
     * @return The buffered file read from the stream
     * @throws IOException If an I/O error occurs
     */
    public static BufferedFile readFrom(DataInputStream in) throws IOException {
        String fileName = in.readUTF();
        long timestamp = in.readLong();
        int length = in.readInt();
        byte[] data = new byte[length];
        in.readFully(data);
        
        BufferedFile file = new BufferedFile(fileName, data);
        return file;
    }
    
    @Override
    public String toString() {
        return "BufferedFile{" +
                "fileName='" + fileName + '\'' +
                ", size=" + size +
                ", timestamp=" + timestamp +
                ", containerName='" + containerName + '\'' +
                ", offsetInContainer=" + offsetInContainer +
                ", isWritten=" + isWritten +
                '}';
    }
}
