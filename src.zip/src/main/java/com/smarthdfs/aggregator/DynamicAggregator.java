package com.smarthdfs.aggregator;

import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.index.IndexEntry;
import com.smarthdfs.index.IndexManager;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.BytesWritable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Dynamic Aggregator - The core component for aggregating small files.
 * This class implements the buffered write algorithm that accumulates small files
 * and writes them as a single SequenceFile when the buffer reaches the threshold.
 * 
 * Algorithm:
 * 1. Buffer small files in memory until threshold is reached
 * 2. When buffer is full, create a SequenceFile container
 * 3. Write all buffered files to the container
 * 4. Update the index with file locations
 * 5. Clear the buffer and repeat
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class DynamicAggregator {
    
    private static final Logger LOG = LoggerFactory.getLogger(DynamicAggregator.class);
    
    private final SmartHdfsConfig config;
    private final FileSystem fileSystem;
    private final IndexManager indexManager;
    
    // Buffer management
    private final Map<String, BufferedFile> fileBuffer;
    private final AtomicLong currentBufferSize;
    private final ReentrantLock bufferLock;
    
    // Container management
    private final AtomicLong containerCounter;
    private String currentContainerName;
    
    // Auto-flush scheduler
    private final ScheduledExecutorService scheduler;
    
    // Statistics
    private final AtomicLong totalFilesBuffered;
    private final AtomicLong totalFilesFlushed;
    private final AtomicLong totalBytesWritten;
    
    /**
     * Constructor for DynamicAggregator
     * 
     * @param config The configuration
     * @param fileSystem The HDFS filesystem
     * @param indexManager The index manager
     * @throws IOException If initialization fails
     */
    public DynamicAggregator(SmartHdfsConfig config, FileSystem fileSystem, 
                            IndexManager indexManager) throws IOException {
        this.config = config;
        this.fileSystem = fileSystem;
        this.indexManager = indexManager;
        
        this.fileBuffer = new ConcurrentHashMap<>();
        this.currentBufferSize = new AtomicLong(0);
        this.bufferLock = new ReentrantLock();
        
        this.containerCounter = new AtomicLong(0);
        this.currentContainerName = generateContainerName();
        
        this.totalFilesBuffered = new AtomicLong(0);
        this.totalFilesFlushed = new AtomicLong(0);
        this.totalBytesWritten = new AtomicLong(0);
        
        // Initialize auto-flush scheduler
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        if (config.isEnableAutoFlush()) {
            startAutoFlush();
        }
        
        // Ensure container directory exists
        Path containerDir = new Path(config.getContainerDir());
        if (!fileSystem.exists(containerDir)) {
            fileSystem.mkdirs(containerDir);
            LOG.info("Created container directory: {}", containerDir);
        }
        
        LOG.info("DynamicAggregator initialized with config: {}", config);
    }
    
    /**
     * Add a file to the buffer. If the buffer size exceeds threshold,
     * flush the buffer to a container file.
     * 
     * @param fileName The file name/path
     * @param data The file data
     * @return IndexEntry containing the file location info
     * @throws IOException If an I/O error occurs
     */
    public IndexEntry addFile(String fileName, byte[] data) throws IOException {
        BufferedFile bufferedFile = new BufferedFile(fileName, data);
        
        // Check if file is small enough for buffering
        if (data.length >= config.getSmallFileThreshold()) {
            LOG.debug("File {} is large ({} bytes), skipping buffer", fileName, data.length);
            return null; // Indicate direct write
        }
        
        bufferLock.lock();
        try {
            fileBuffer.put(fileName, bufferedFile);
            currentBufferSize.addAndGet(data.length);
            totalFilesBuffered.incrementAndGet();
            
            LOG.debug("Buffered file: {} ({} bytes), buffer size: {} bytes", 
                     fileName, data.length, currentBufferSize.get());
            
            // Check if buffer should be flushed
            if (currentBufferSize.get() >= config.getBufferSize()) {
                LOG.info("Buffer threshold reached ({} bytes), flushing...", currentBufferSize.get());
                flushBuffer();
            }
            
            return new IndexEntry(fileName, currentContainerName, -1, data.length);
        } finally {
            bufferLock.unlock();
        }
    }
    
    /**
     * Flush the buffer to a SequenceFile container
     * 
     * @throws IOException If an I/O error occurs
     */
    public void flushBuffer() throws IOException {
        bufferLock.lock();
        try {
            if (fileBuffer.isEmpty()) {
                LOG.debug("Buffer is empty, nothing to flush");
                return;
            }
            
            Path containerPath = new Path(config.getContainerDir(), currentContainerName);
            long containerSize = 0;
            int filesWritten = 0;
            
            LOG.info("Flushing {} files to container: {}", fileBuffer.size(), containerPath);
            
            // Create SequenceFile writer
            SequenceFile.Writer.Option fileOption = SequenceFile.Writer.file(containerPath);
            SequenceFile.Writer.Option keyClassOption = SequenceFile.Writer.keyClass(Text.class);
            SequenceFile.Writer.Option valueClassOption = SequenceFile.Writer.valueClass(BytesWritable.class);
            
            try (SequenceFile.Writer writer = SequenceFile.createWriter(
                    fileSystem.getConf(), fileOption, keyClassOption, valueClassOption)) {
                
                Text key = new Text();
                BytesWritable value = new BytesWritable();
                
                // Write each buffered file
                for (Map.Entry<String, BufferedFile> entry : fileBuffer.entrySet()) {
                    BufferedFile bufferedFile = entry.getValue();
                    
                    // Get current position (offset) in the container
                    long offset = writer.getLength();
                    
                    // Set key and value
                    key.set(bufferedFile.getFileName());
                    value.set(bufferedFile.getData(), 0, (int) bufferedFile.getSize());
                    
                    // Write to container
                    writer.append(key, value);
                    
                    // Update index
                    IndexEntry indexEntry = new IndexEntry(
                            bufferedFile.getFileName(),
                            currentContainerName,
                            offset,
                            bufferedFile.getSize()
                    );
                    indexManager.addEntry(indexEntry);
                    
                    // Update file metadata
                    bufferedFile.setContainerName(currentContainerName);
                    bufferedFile.setOffsetInContainer(offset);
                    bufferedFile.setWritten(true);
                    
                    containerSize += bufferedFile.getSize();
                    filesWritten++;
                }
            }
            
            // Update statistics
            totalFilesFlushed.addAndGet(filesWritten);
            totalBytesWritten.addAndGet(containerSize);
            
            // Persist index
            indexManager.persistIndex(currentContainerName);
            
            // Clear buffer and prepare new container
            fileBuffer.clear();
            currentBufferSize.set(0);
            currentContainerName = generateContainerName();
            
            LOG.info("Flushed {} files ({} bytes) to {}", filesWritten, containerSize, containerPath);
            
        } finally {
            bufferLock.unlock();
        }
    }
    
    /**
     * Force flush all pending files in the buffer
     * 
     * @throws IOException If an I/O error occurs
     */
    public void forceFlush() throws IOException {
        LOG.info("Force flushing buffer...");
        flushBuffer();
    }
    
    /**
     * Get a file from the buffer or read from container
     * 
     * @param fileName The file name to retrieve
     * @return The file data, or null if not found
     * @throws IOException If an I/O error occurs
     */
    public byte[] getFile(String fileName) throws IOException {
        // Check if file is still in buffer
        bufferLock.lock();
        try {
            BufferedFile bufferedFile = fileBuffer.get(fileName);
            if (bufferedFile != null) {
                LOG.debug("File {} found in buffer", fileName);
                return bufferedFile.getData();
            }
        } finally {
            bufferLock.unlock();
        }
        
        // Check index and read from container
        IndexEntry entry = indexManager.getEntry(fileName);
        if (entry != null) {
            LOG.debug("File {} found in container {} at offset {}", 
                     fileName, entry.getContainerName(), entry.getOffset());
            return readFileFromContainer(entry);
        }
        
        LOG.debug("File {} not found", fileName);
        return null;
    }
    
    /**
     * Read a file from a container using the index entry
     * 
     * @param entry The index entry containing location info
     * @return The file data
     * @throws IOException If an I/O error occurs
     */
    private byte[] readFileFromContainer(IndexEntry entry) throws IOException {
        Path containerPath = new Path(config.getContainerDir(), entry.getContainerName());
        
        try (SequenceFile.Reader reader = new SequenceFile.Reader(
                fileSystem.getConf(), SequenceFile.Reader.file(containerPath))) {
            
            Text key = new Text();
            BytesWritable value = new BytesWritable();
            
            // Seek to approximate position (SequenceFile doesn't support exact seek)
            // We need to read until we find our file
            while (reader.next(key, value)) {
                if (key.toString().equals(entry.getFileName())) {
                    byte[] data = new byte[value.getLength()];
                    System.arraycopy(value.getBytes(), 0, data, 0, value.getLength());
                    return data;
                }
            }
        }
        
        throw new IOException("File not found in container: " + entry.getFileName());
    }
    
    /**
     * Generate a unique container file name
     * 
     * @return The container file name
     */
    private String generateContainerName() {
        return config.getContainerPrefix() + System.currentTimeMillis() + 
               "_" + containerCounter.getAndIncrement() + ".seq";
    }
    
    /**
     * Start the auto-flush scheduler
     */
    private void startAutoFlush() {
        scheduler.scheduleAtFixedRate(() -> {
            try {
                if (!fileBuffer.isEmpty()) {
                    LOG.debug("Auto-flush triggered, buffer size: {} bytes", currentBufferSize.get());
                    flushBuffer();
                }
            } catch (IOException e) {
                LOG.error("Auto-flush failed", e);
            }
        }, config.getFlushIntervalMs(), config.getFlushIntervalMs(), TimeUnit.MILLISECONDS);
        
        LOG.info("Auto-flush scheduled every {} ms", config.getFlushIntervalMs());
    }
    
    /**
     * Get current buffer size
     * 
     * @return The current buffer size in bytes
     */
    public long getCurrentBufferSize() {
        return currentBufferSize.get();
    }
    
    /**
     * Get the number of files currently in buffer
     * 
     * @return The number of buffered files
     */
    public int getBufferedFileCount() {
        return fileBuffer.size();
    }
    
    /**
     * Get statistics
     * 
     * @return Statistics map
     */
    public Map<String, Long> getStatistics() {
        Map<String, Long> stats = new ConcurrentHashMap<>();
        stats.put("totalFilesBuffered", totalFilesBuffered.get());
        stats.put("totalFilesFlushed", totalFilesFlushed.get());
        stats.put("totalBytesWritten", totalBytesWritten.get());
        stats.put("currentBufferSize", currentBufferSize.get());
        stats.put("currentBufferCount", (long) fileBuffer.size());
        return stats;
    }
    
    /**
     * Shutdown the aggregator and flush remaining files
     * 
     * @throws IOException If an I/O error occurs
     */
    public void shutdown() throws IOException {
        LOG.info("Shutting down DynamicAggregator...");
        
        // Stop scheduler
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(10, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        
        // Flush remaining files
        if (!fileBuffer.isEmpty()) {
            LOG.info("Flushing remaining {} files before shutdown", fileBuffer.size());
            flushBuffer();
        }
        
        LOG.info("DynamicAggregator shutdown complete");
    }
}
