package com.smarthdfs.benchmark;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Performance Comparison Tool - Compares Smart HDFS Client vs Standard HDFS.
 * 
 * This class provides side-by-side comparison of performance metrics
 * between the Smart HDFS Client and standard HDFS operations.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class PerformanceComparison {
    
    private final BenchmarkRunner smartClientBenchmark;
    private final BenchmarkRunner standardHdfsBenchmark;
    
    private ComparisonResult lastComparison;
    
    /**
     * Constructor for PerformanceComparison
     */
    public PerformanceComparison() {
        this.smartClientBenchmark = new BenchmarkRunner();
        this.standardHdfsBenchmark = new BenchmarkRunner();
    }
    
    /**
     * Get the Smart Client benchmark runner
     */
    public BenchmarkRunner getSmartClientBenchmark() {
        return smartClientBenchmark;
    }
    
    /**
     * Get the Standard HDFS benchmark runner
     */
    public BenchmarkRunner getStandardHdfsBenchmark() {
        return standardHdfsBenchmark;
    }
    
    /**
     * Run a comparison benchmark
     * 
     * @param testName The test name
     * @param smartClientOp The Smart Client operation
     * @param standardOp The Standard HDFS operation
     * @param bytesProcessed The number of bytes processed
     */
    public void runComparison(String testName, Runnable smartClientOp, 
                             Runnable standardOp, long bytesProcessed) {
        
        System.out.println("\n=== Running Comparison: " + testName + " ===\n");
        
        // Run Smart Client benchmark
        System.out.println("Running Smart Client benchmark...");
        smartClientBenchmark.startMemoryTracking();
        long smartDuration = smartClientBenchmark.runBenchmark(
                testName + "_smart_client", smartClientOp, bytesProcessed);
        smartClientBenchmark.stopMemoryTracking();
        
        // Allow GC between tests
        System.gc();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Run Standard HDFS benchmark
        System.out.println("Running Standard HDFS benchmark...");
        standardHdfsBenchmark.startMemoryTracking();
        long standardDuration = standardHdfsBenchmark.runBenchmark(
                testName + "_standard_hdfs", standardOp, bytesProcessed);
        standardHdfsBenchmark.stopMemoryTracking();
        
        // Calculate comparison
        lastComparison = calculateComparison(smartDuration, standardDuration);
    }
    
    /**
     * Calculate comparison between two durations
     */
    private ComparisonResult calculateComparison(long smartDuration, long standardDuration) {
        double improvement = 0;
        if (standardDuration > 0) {
            improvement = ((double) (standardDuration - smartDuration) / standardDuration) * 100;
        }
        
        return new ComparisonResult(smartDuration, standardDuration, improvement);
    }
    
    /**
     * Generate a comprehensive comparison report
     * 
     * @return Formatted comparison report
     */
    public String generateComparisonReport() {
        StringBuilder report = new StringBuilder();
        
        Map<String, Object> smartStats = smartClientBenchmark.getStatistics();
        Map<String, Object> standardStats = standardHdfsBenchmark.getStatistics();
        
        report.append("\n");
        report.append("╔════════════════════════════════════════════════════════════════════════════════╗\n");
        report.append("║                    PERFORMANCE COMPARISON REPORT                               ║\n");
        report.append("║            Smart HDFS Client vs Standard HDFS Client                          ║\n");
        report.append("╚════════════════════════════════════════════════════════════════════════════════╝\n");
        report.append("\n");
        
        // Write performance comparison
        report.append("┌──────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ WRITE PERFORMANCE COMPARISON                                                  │\n");
        report.append("├────────────────────────────┬─────────────────────┬───────────────────────────┤\n");
        report.append("│ Metric                     │ Smart Client        │ Standard HDFS             │\n");
        report.append("├────────────────────────────┼─────────────────────┼───────────────────────────┤\n");
        
        long smartWriteTime = (long) smartStats.getOrDefault("totalWriteTimeMs", 0L);
        long standardWriteTime = (long) standardStats.getOrDefault("totalWriteTimeMs", 0L);
        report.append(String.format("│ Total Write Time (ms)      │ %,19d │ %,25d │%n", 
                smartWriteTime, standardWriteTime));
        
        double smartWriteThroughput = (double) smartStats.getOrDefault("writeThroughputBps", 0.0) / (1024 * 1024);
        double standardWriteThroughput = (double) standardStats.getOrDefault("writeThroughputBps", 0.0) / (1024 * 1024);
        report.append(String.format("│ Write Throughput (MB/s)    │ %,19.2f │ %,25.2f │%n", 
                smartWriteThroughput, standardWriteThroughput));
        
        report.append("└────────────────────────────┴─────────────────────┴───────────────────────────┘\n");
        report.append("\n");
        
        // Read performance comparison
        report.append("┌──────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ READ PERFORMANCE COMPARISON                                                   │\n");
        report.append("├────────────────────────────┬─────────────────────┬───────────────────────────┤\n");
        report.append("│ Metric                     │ Smart Client        │ Standard HDFS             │\n");
        report.append("├────────────────────────────┼─────────────────────┼───────────────────────────┤\n");
        
        long smartReadTime = (long) smartStats.getOrDefault("totalReadTimeMs", 0L);
        long standardReadTime = (long) standardStats.getOrDefault("totalReadTimeMs", 0L);
        report.append(String.format("│ Total Read Time (ms)       │ %,19d │ %,25d │%n", 
                smartReadTime, standardReadTime));
        
        double smartReadThroughput = (double) smartStats.getOrDefault("readThroughputBps", 0.0) / (1024 * 1024);
        double standardReadThroughput = (double) standardStats.getOrDefault("readThroughputBps", 0.0) / (1024 * 1024);
        report.append(String.format("│ Read Throughput (MB/s)     │ %,19.2f │ %,25.2f │%n", 
                smartReadThroughput, standardReadThroughput));
        
        report.append("└────────────────────────────┴─────────────────────┴───────────────────────────┘\n");
        report.append("\n");
        
        // Memory comparison
        report.append("┌──────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ MEMORY USAGE COMPARISON                                                       │\n");
        report.append("├────────────────────────────┬─────────────────────┬───────────────────────────┤\n");
        report.append("│ Metric                     │ Smart Client        │ Standard HDFS             │\n");
        report.append("├────────────────────────────┼─────────────────────┼───────────────────────────┤\n");
        
        long smartMemoryUsed = (long) smartStats.getOrDefault("memoryUsedBytes", 0L);
        long standardMemoryUsed = (long) standardStats.getOrDefault("memoryUsedBytes", 0L);
        report.append(String.format("│ Memory Used (MB)           │ %,19.2f │ %,25.2f │%n", 
                smartMemoryUsed / (1024.0 * 1024), standardMemoryUsed / (1024.0 * 1024)));
        
        report.append("└────────────────────────────┴─────────────────────┴───────────────────────────┘\n");
        report.append("\n");
        
        // Estimated NameNode impact
        report.append("┌──────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ ESTIMATED NAMENODE IMPACT                                                     │\n");
        report.append("├────────────────────────────────────────────────────────────────────────────┤\n");
        
        long smartFiles = (long) smartStats.getOrDefault("totalFilesProcessed", 0L);
        long standardFiles = (long) standardStats.getOrDefault("totalFilesProcessed", 0L);
        
        // Each file uses ~150 bytes in NameNode memory
        long smartNameNodeMemory = smartFiles * 150;
        long standardNameNodeMemory = standardFiles * 150;
        
        // Assuming 100:1 aggregation ratio
        long smartContainerFiles = (long) Math.ceil(smartFiles / 100.0);
        long smartActualNameNodeMemory = smartContainerFiles * 150;
        
        double memorySavingsPercent = 0;
        if (standardNameNodeMemory > 0) {
            memorySavingsPercent = ((double) (standardNameNodeMemory - smartActualNameNodeMemory) / standardNameNodeMemory) * 100;
        }
        
        report.append(String.format("│ Files Written (Standard):  %,d%n", standardFiles));
        report.append(String.format("│ Files Written (Smart):     %,d (aggregated into %,d containers)%n", 
                smartFiles, smartContainerFiles));
        report.append(String.format("│ NameNode Memory (Standard): %,.2f MB%n", 
                standardNameNodeMemory / (1024.0 * 1024)));
        report.append(String.format("│ NameNode Memory (Smart):    %,.2f MB%n", 
                smartActualNameNodeMemory / (1024.0 * 1024)));
        report.append(String.format("│ Memory Savings:             %.1f%%%n", memorySavingsPercent));
        
        report.append("└──────────────────────────────────────────────────────────────────────────────┘\n");
        
        return report.toString();
    }
    
    /**
     * Get the last comparison result
     */
    public ComparisonResult getLastComparison() {
        return lastComparison;
    }
    
    /**
     * Export comparison data to CSV
     * 
     * @return CSV string
     */
    public String exportComparisonToCsv() {
        StringBuilder csv = new StringBuilder();
        csv.append("metric,smart_client,standard_hdfs,improvement_percent\n");
        
        Map<String, Object> smartStats = smartClientBenchmark.getStatistics();
        Map<String, Object> standardStats = standardHdfsBenchmark.getStatistics();
        
        // Write time
        long smartWriteTime = (long) smartStats.getOrDefault("totalWriteTimeMs", 0L);
        long standardWriteTime = (long) standardStats.getOrDefault("totalWriteTimeMs", 0L);
        double writeImprovement = standardWriteTime > 0 ? 
                ((double) (standardWriteTime - smartWriteTime) / standardWriteTime) * 100 : 0;
        csv.append(String.format("write_time_ms,%d,%d,%.2f%n", 
                smartWriteTime, standardWriteTime, writeImprovement));
        
        // Read time
        long smartReadTime = (long) smartStats.getOrDefault("totalReadTimeMs", 0L);
        long standardReadTime = (long) standardStats.getOrDefault("totalReadTimeMs", 0L);
        double readImprovement = standardReadTime > 0 ? 
                ((double) (standardReadTime - smartReadTime) / standardReadTime) * 100 : 0;
        csv.append(String.format("read_time_ms,%d,%d,%.2f%n", 
                smartReadTime, standardReadTime, readImprovement));
        
        // Memory
        long smartMemory = (long) smartStats.getOrDefault("memoryUsedBytes", 0L);
        long standardMemory = (long) standardStats.getOrDefault("memoryUsedBytes", 0L);
        csv.append(String.format("memory_bytes,%d,%d,0%n", smartMemory, standardMemory));
        
        return csv.toString();
    }
    
    /**
     * Reset both benchmark runners
     */
    public void reset() {
        smartClientBenchmark.reset();
        standardHdfsBenchmark.reset();
        lastComparison = null;
    }
    
    /**
     * Inner class for comparison results
     */
    public static class ComparisonResult {
        private final long smartClientDurationMs;
        private final long standardHdfsDurationMs;
        private final double improvementPercent;
        
        public ComparisonResult(long smartClientDurationMs, long standardHdfsDurationMs, 
                               double improvementPercent) {
            this.smartClientDurationMs = smartClientDurationMs;
            this.standardHdfsDurationMs = standardHdfsDurationMs;
            this.improvementPercent = improvementPercent;
        }
        
        public long getSmartClientDurationMs() { return smartClientDurationMs; }
        public long getStandardHdfsDurationMs() { return standardHdfsDurationMs; }
        public double getImprovementPercent() { return improvementPercent; }
        
        @Override
        public String toString() {
            return String.format(
                    "Smart Client: %d ms, Standard HDFS: %d ms, Improvement: %.1f%%",
                    smartClientDurationMs, standardHdfsDurationMs, improvementPercent);
        }
    }
}
