package com.smarthdfs.benchmark;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Enhanced Benchmark Runner with Seek Time and Random Read Analysis.
 * 
 * This class addresses the research gaps identified in previous studies:
 * 
 * 1. SEEK TIME MODELING - Previous studies (Liu et al., 2019) did not account
 *    for seek time when reading from aggregated containers (SequenceFile).
 * 
 * 2. RANDOM READ SCENARIOS - Previous solutions suffer from poor random read
 *    performance that needs to be quantified.
 * 
 * 3. INDEXING OVERHEAD - Side-car index adds lookup time that must be measured.
 * 
 * 4. COMPREHENSIVE COMPARISON - Side-by-side comparison with all major approaches.
 * 
 * @author Smart HDFS Research Team
 * @version 2.0.0
 */
public class EnhancedBenchmarkRunner {
    
    // Configuration parameters
    private final int blockSizeMB;
    private final int bufferSizeMB;
    private final double indexLookupTimeMs;
    private final double containerSeekTimeMs;
    private final double indexCacheHitRatio;
    
    // Results storage
    private final List<EnhancedResult> results;
    private final Map<String, IndexEntry> indexCache;
    
    // Statistics
    private final AtomicLong totalWriteTime;
    private final AtomicLong totalReadTime;
    private final AtomicLong cacheHits;
    private final AtomicLong cacheMisses;
    
    /**
     * Default constructor with standard HDFS configuration
     */
    public EnhancedBenchmarkRunner() {
        this(128, 64, 0.5, 1.2, 0.85);
    }
    
    /**
     * Constructor with custom configuration
     */
    public EnhancedBenchmarkRunner(int blockSizeMB, int bufferSizeMB, 
                                   double indexLookupTimeMs, double containerSeekTimeMs,
                                   double indexCacheHitRatio) {
        this.blockSizeMB = blockSizeMB;
        this.bufferSizeMB = bufferSizeMB;
        this.indexLookupTimeMs = indexLookupTimeMs;
        this.containerSeekTimeMs = containerSeekTimeMs;
        this.indexCacheHitRatio = indexCacheHitRatio;
        
        this.results = new ArrayList<>();
        this.indexCache = new ConcurrentHashMap<>();
        this.totalWriteTime = new AtomicLong(0);
        this.totalReadTime = new AtomicLong(0);
        this.cacheHits = new AtomicLong(0);
        this.cacheMisses = new AtomicLong(0);
    }
    
    /**
     * Simulate standard HDFS write operation
     */
    public double simulateStandardWrite(int fileCount, int avgFileSizeBytes) {
        double totalTime = 0.0;
        
        for (int i = 0; i < fileCount; i++) {
            // NameNode RPC for file creation
            double namenodeRpc = 1.0 + randomVariance(0.3);
            totalTime += namenodeRpc;
            
            // Block allocation
            double blockAllocation = 0.5 + randomVariance(0.2);
            totalTime += blockAllocation;
            
            // Data transfer
            double transferTime = calculateTransferTime(avgFileSizeBytes);
            totalTime += transferTime;
            
            // Network latency (3 replicas)
            for (int r = 0; r < 3; r++) {
                totalTime += networkLatency();
            }
            
            // Acknowledgment
            totalTime += 0.2;
        }
        
        // Memory pressure effect for large file counts
        double memoryPressure = 1 + (fileCount / 50000.0) * 0.1;
        totalTime *= memoryPressure;
        
        return totalTime;
    }
    
    /**
     * Simulate Smart HDFS Client write operation
     */
    public SmartWriteResult simulateSmartWrite(int fileCount, int avgFileSizeBytes) {
        double totalTime = 0.0;
        
        // Calculate container count
        long totalData = (long) fileCount * avgFileSizeBytes;
        long containerSize = blockSizeMB * 1024L * 1024;
        int containerCount = Math.max(1, (int) Math.ceil((double) totalData / containerSize));
        int filesPerContainer = fileCount / containerCount;
        
        // Buffer filling time
        double bufferFillTime = fileCount * 0.5;
        totalTime += bufferFillTime;
        
        // Container write operations
        for (int c = 0; c < containerCount; c++) {
            // Open container
            double containerOpen = 2.0 + randomVariance(0.35);
            totalTime += containerOpen;
            
            // Write data (batched)
            long dataInContainer = Math.min((long) filesPerContainer * avgFileSizeBytes, containerSize);
            double transferTime = calculateTransferTime(dataInContainer) * 0.8;
            totalTime += transferTime;
            
            // Network latency (single write per container)
            for (int r = 0; r < 3; r++) {
                totalTime += networkLatency();
            }
            
            // Index update
            totalTime += 0.1 * filesPerContainer;
            
            // Close container
            totalTime += 0.5;
        }
        
        // Create index entries
        for (int i = 0; i < fileCount; i++) {
            int containerId = i / Math.max(1, filesPerContainer);
            long offset = (long) (i % Math.max(1, filesPerContainer)) * avgFileSizeBytes;
            indexCache.put("file_" + i, new IndexEntry(containerId, offset, avgFileSizeBytes));
        }
        
        return new SmartWriteResult(totalTime, containerCount);
    }
    
    /**
     * Simulate sequential read in standard HDFS
     */
    public double simulateStandardSequentialRead(int fileCount, int sampleSize, int avgFileSizeBytes) {
        double totalTime = 0.0;
        
        for (int i = 0; i < Math.min(sampleSize, fileCount); i++) {
            // NameNode lookup
            double namenodeLookup = 0.3 + randomVariance(0.1);
            totalTime += namenodeLookup;
            
            // Network latency
            totalTime += networkLatency();
            
            // Data transfer
            totalTime += calculateTransferTime(avgFileSizeBytes);
        }
        
        return totalTime;
    }
    
    /**
     * Simulate sequential read with Smart HDFS Client
     */
    public SeekTimeResult simulateSmartSequentialRead(int fileCount, int sampleSize, int avgFileSizeBytes) {
        double totalTime = 0.0;
        double containerOpenTime = 0.0;
        double indexLookupTime = 0.0;
        double positionSeekTime = 0.0;
        
        int currentContainer = -1;
        int containerCount = (int) Math.ceil((double) fileCount / (blockSizeMB * 1024 * 1024 / avgFileSizeBytes));
        
        for (int i = 0; i < Math.min(sampleSize, fileCount); i++) {
            String filePath = "file_" + i;
            IndexEntry entry = indexCache.get(filePath);
            
            if (entry != null) {
                // Container open time (only if different container)
                if (entry.containerId != currentContainer) {
                    double openTime = 2.0 + randomVariance(0.2);
                    containerOpenTime += openTime;
                    totalTime += openTime;
                    currentContainer = entry.containerId;
                }
                
                // Index lookup time
                boolean cacheHit = Math.random() < indexCacheHitRatio;
                double lookupTime = cacheHit ? 0.1 : 0.5;
                indexLookupTime += lookupTime;
                totalTime += lookupTime;
                
                if (cacheHit) {
                    cacheHits.incrementAndGet();
                } else {
                    cacheMisses.incrementAndGet();
                }
                
                // Position seek (minimal for sequential)
                double seekTime = 0.05;
                positionSeekTime += seekTime;
                totalTime += seekTime;
                
                // Data transfer
                totalTime += calculateTransferTime(avgFileSizeBytes) * 0.95;
            }
        }
        
        return new SeekTimeResult(totalTime, containerOpenTime, indexLookupTime, positionSeekTime);
    }
    
    /**
     * Simulate random read in standard HDFS
     */
    public double simulateStandardRandomRead(int fileCount, int sampleSize, int avgFileSizeBytes) {
        double totalTime = 0.0;
        Random random = new Random();
        
        for (int i = 0; i < sampleSize; i++) {
            // NameNode lookup (every random access needs lookup)
            double namenodeLookup = 0.5 + randomVariance(0.2);
            totalTime += namenodeLookup;
            
            // Disk seek for each random access
            totalTime += 5.0 + randomVariance(1.0);
            
            // Network latency
            totalTime += networkLatency();
            
            // Data transfer
            totalTime += calculateTransferTime(avgFileSizeBytes);
        }
        
        return totalTime;
    }
    
    /**
     * Simulate random read with Smart HDFS Client - includes seek time
     */
    public SeekTimeResult simulateSmartRandomRead(int fileCount, int sampleSize, int avgFileSizeBytes) {
        double totalTime = 0.0;
        double containerOpenTime = 0.0;
        double indexLookupTime = 0.0;
        double positionSeekTime = 0.0;
        
        Random random = new Random();
        int containerCount = (int) Math.ceil((double) fileCount / (blockSizeMB * 1024 * 1024 / avgFileSizeBytes));
        int filesPerContainer = fileCount / Math.max(1, containerCount);
        
        for (int i = 0; i < sampleSize; i++) {
            int fileIdx = random.nextInt(fileCount);
            String filePath = "file_" + fileIdx;
            IndexEntry entry = indexCache.get(filePath);
            
            if (entry != null) {
                // Container open time
                double openTime = 2.0 + randomVariance(0.35);
                containerOpenTime += openTime;
                totalTime += openTime;
                
                // Index lookup time (longer for random access)
                boolean cacheHit = Math.random() < indexCacheHitRatio;
                double lookupTime = cacheHit ? 0.15 : 0.6;
                indexLookupTime += lookupTime;
                totalTime += lookupTime;
                
                if (cacheHit) {
                    cacheHits.incrementAndGet();
                } else {
                    cacheMisses.incrementAndGet();
                }
                
                // Position seek within container (key overhead for random reads!)
                int seekDistance = random.nextInt((int) (filesPerContainer * avgFileSizeBytes));
                double seekTime = calculateDiskSeekTime(seekDistance);
                positionSeekTime += seekTime;
                totalTime += seekTime;
                
                // Data transfer
                totalTime += calculateTransferTime(avgFileSizeBytes);
            }
        }
        
        return new SeekTimeResult(totalTime, containerOpenTime, indexLookupTime, positionSeekTime);
    }
    
    /**
     * Calculate disk seek time based on seek distance
     */
    private double calculateDiskSeekTime(long seekDistanceBytes) {
        double baseSeek = 5.0;  // Base disk seek time in ms
        double rotationLatency = 2.0;  // Average rotational latency
        
        // Additional seek time based on distance (simplified model)
        double distanceFactor = Math.min(1.0, (double) seekDistanceBytes / (128 * 1024 * 1024)) * 2.0;
        
        return baseSeek + rotationLatency + distanceFactor;
    }
    
    /**
     * Calculate data transfer time
     */
    private double calculateTransferTime(long bytesCount) {
        double mb = bytesCount / (1024.0 * 1024);
        double transferRateMbps = 150;  // MB/s
        return (mb / transferRateMbps) * 1000;  // Convert to milliseconds
    }
    
    /**
     * Generate network latency with variance
     */
    private double networkLatency() {
        return 0.5 + randomVariance(0.3);
    }
    
    /**
     * Generate random variance
     */
    private double randomVariance(double range) {
        return (Math.random() - 0.5) * 2 * range;
    }
    
    /**
     * Run comprehensive benchmark
     */
    public EnhancedResult runBenchmark(int fileCount, int avgFileSizeKB) {
        int avgFileSizeBytes = avgFileSizeKB * 1024;
        int sampleSize = Math.min(100, fileCount);
        
        // Write benchmarks
        double standardWrite = simulateStandardWrite(fileCount, avgFileSizeBytes);
        SmartWriteResult smartWriteResult = simulateSmartWrite(fileCount, avgFileSizeBytes);
        double smartWrite = smartWriteResult.timeMs;
        int containerCount = smartWriteResult.containerCount;
        
        // Sequential read benchmarks
        double standardSeqRead = simulateStandardSequentialRead(fileCount, sampleSize, avgFileSizeBytes);
        SeekTimeResult smartSeqReadResult = simulateSmartSequentialRead(fileCount, sampleSize, avgFileSizeBytes);
        double smartSeqRead = smartSeqReadResult.totalTimeMs;
        
        // Random read benchmarks
        double standardRandomRead = simulateStandardRandomRead(fileCount, sampleSize, avgFileSizeBytes);
        SeekTimeResult smartRandomReadResult = simulateSmartRandomRead(fileCount, sampleSize, avgFileSizeBytes);
        double smartRandomRead = smartRandomReadResult.totalTimeMs;
        
        // Calculate metrics
        double writeImprovement = ((standardWrite - smartWrite) / standardWrite) * 100;
        double seqReadOverhead = ((smartSeqRead - standardSeqRead) / standardSeqRead) * 100;
        double randomReadOverhead = ((smartRandomRead - standardRandomRead) / standardRandomRead) * 100;
        
        // Memory calculations
        long standardMemory = (long) fileCount * 150;  // 150 bytes per file in NameNode
        long smartMemory = (long) containerCount * 150;  // Only containers are tracked
        double memorySavings = ((double) (standardMemory - smartMemory) / standardMemory) * 100;
        
        // Index metrics
        long indexSize = (long) fileCount * 64;  // 64 bytes per index entry
        double cacheHitRatio = cacheHits.get() + cacheMisses.get() > 0 
            ? (double) cacheHits.get() / (cacheHits.get() + cacheMisses.get()) 
            : 0;
        double indexOverheadPct = smartRandomReadResult.indexLookupTimeMs / smartRandomReadResult.totalTimeMs * 100;
        
        EnhancedResult result = new EnhancedResult(
            new Date(),
            fileCount,
            avgFileSizeKB,
            standardWrite,
            smartWrite,
            writeImprovement,
            standardSeqRead,
            smartSeqRead,
            seqReadOverhead,
            standardRandomRead,
            smartRandomRead,
            randomReadOverhead,
            smartRandomReadResult.containerOpenTimeMs,
            smartRandomReadResult.indexLookupTimeMs,
            smartRandomReadResult.positionSeekTimeMs,
            smartRandomReadResult.totalTimeMs / sampleSize,
            standardMemory,
            smartMemory,
            memorySavings,
            containerCount,
            (double) fileCount / containerCount,
            indexSize,
            cacheHitRatio,
            indexOverheadPct
        );
        
        results.add(result);
        return result;
    }
    
    /**
     * Generate comprehensive report
     */
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        
        report.append("\n");
        report.append("╔════════════════════════════════════════════════════════════════════════════════╗\n");
        report.append("║           ENHANCED BENCHMARK RESULTS - ADDRESSING RESEARCH GAPS                ║\n");
        report.append("╚════════════════════════════════════════════════════════════════════════════════╝\n");
        report.append("\n");
        
        report.append("┌────────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ CONFIGURATION                                                                  │\n");
        report.append("├────────────────────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Block Size: %d MB     Buffer Size: %d MB     Index Cache Hit Ratio: %.0f%%       │\n", 
                blockSizeMB, bufferSizeMB, indexCacheHitRatio * 100));
        report.append(String.format("│ Index Lookup Time: %.1f ms     Container Seek Time: %.1f ms                      │\n",
                indexLookupTimeMs, containerSeekTimeMs));
        report.append("└────────────────────────────────────────────────────────────────────────────────┘\n");
        report.append("\n");
        
        // Results table
        report.append("┌────────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ WRITE PERFORMANCE COMPARISON                                                   │\n");
        report.append("├──────────┬───────────────┬───────────────┬───────────────┬────────────────────┤\n");
        report.append("│ Files    │ Standard (ms) │ Smart (ms)    │ Improvement   │ Containers         │\n");
        report.append("├──────────┼───────────────┼───────────────┼───────────────┼────────────────────┤\n");
        
        for (EnhancedResult r : results) {
            report.append(String.format("│ %,8d │ %,13.1f │ %,13.1f │ %+12.1f%% │ %,18d │\n",
                    r.fileCount, r.standardWriteMs, r.smartWriteMs, r.writeImprovementPct, r.containerCount));
        }
        
        report.append("└──────────┴───────────────┴───────────────┴───────────────┴────────────────────┘\n");
        report.append("\n");
        
        // Seek time breakdown
        report.append("┌────────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ SEEK TIME BREAKDOWN (per 100 random reads)                                     │\n");
        report.append("├──────────┬───────────────┬───────────────┬───────────────┬────────────────────┤\n");
        report.append("│ Files    │ Container Open│ Index Lookup  │ Position Seek │ Total Overhead     │\n");
        report.append("├──────────┼───────────────┼───────────────┼───────────────┼────────────────────┤\n");
        
        for (EnhancedResult r : results) {
            report.append(String.format("│ %,8d │ %,11.1f ms │ %,11.1f ms │ %,11.1f ms │ %,14.1f ms │\n",
                    r.fileCount, r.containerOpenTimeMs, r.indexLookupTimeMs, 
                    r.positionSeekTimeMs, r.containerOpenTimeMs + r.indexLookupTimeMs + r.positionSeekTimeMs));
        }
        
        report.append("└──────────┴───────────────┴───────────────┴───────────────┴────────────────────┘\n");
        report.append("\n");
        
        // Memory comparison
        report.append("┌────────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ MEMORY USAGE COMPARISON                                                        │\n");
        report.append("├──────────┬───────────────┬───────────────┬───────────────┬────────────────────┤\n");
        report.append("│ Files    │ Standard (KB) │ Smart (KB)    │ Saved         │ Aggregation Ratio  │\n");
        report.append("├──────────┼───────────────┼───────────────┼───────────────┼────────────────────┤\n");
        
        for (EnhancedResult r : results) {
            report.append(String.format("│ %,8d │ %,13.1f │ %,13.1f │ %12.1f%% │ %14.0f:1   │\n",
                    r.fileCount, r.standardMemoryBytes / 1024.0, r.smartMemoryBytes / 1024.0,
                    r.memorySavingsPct, r.aggregationRatio));
        }
        
        report.append("└──────────┴───────────────┴───────────────┴───────────────┴────────────────────┘\n");
        report.append("\n");
        
        // Summary statistics
        double avgWriteImp = results.stream().mapToDouble(r -> r.writeImprovementPct).average().orElse(0);
        double avgSeqOverhead = results.stream().mapToDouble(r -> r.seqReadOverheadPct).average().orElse(0);
        double avgRandomOverhead = results.stream().mapToDouble(r -> r.randomReadOverheadPct).average().orElse(0);
        double avgMemorySaved = results.stream().mapToDouble(r -> r.memorySavingsPct).average().orElse(0);
        
        report.append("┌────────────────────────────────────────────────────────────────────────────────┐\n");
        report.append("│ SUMMARY STATISTICS                                                             │\n");
        report.append("├────────────────────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Average Write Improvement:        %+.1f%%                                      │\n", avgWriteImp));
        report.append(String.format("│ Average Sequential Read Overhead: %+.1f%%                                      │\n", avgSeqOverhead));
        report.append(String.format("│ Average Random Read Overhead:     %+.1f%%                                      │\n", avgRandomOverhead));
        report.append(String.format("│ Average Memory Savings:           %.1f%%                                       │\n", avgMemorySaved));
        report.append("└────────────────────────────────────────────────────────────────────────────────┘\n");
        
        return report.toString();
    }
    
    /**
     * Export results to CSV
     */
    public String exportToCsv() {
        StringBuilder csv = new StringBuilder();
        csv.append("file_count,avg_file_size_kb,standard_write_ms,smart_write_ms,write_improvement_pct,");
        csv.append("standard_seq_read_ms,smart_seq_read_ms,seq_read_overhead_pct,");
        csv.append("standard_random_read_ms,smart_random_read_ms,random_read_overhead_pct,");
        csv.append("container_open_time_ms,index_lookup_time_ms,position_seek_time_ms,avg_seek_time_ms,");
        csv.append("standard_memory_bytes,smart_memory_bytes,memory_savings_pct,");
        csv.append("container_count,aggregation_ratio,index_size_bytes,cache_hit_ratio,index_overhead_pct\n");
        
        for (EnhancedResult r : results) {
            csv.append(String.format("%d,%d,%.2f,%.2f,%.1f,%.2f,%.2f,%.1f,%.2f,%.2f,%.1f,%.2f,%.2f,%.2f,%.3f,%d,%d,%.1f,%d,%.0f,%d,%.2f,%.2f\n",
                    r.fileCount, r.avgFileSizeKb, r.standardWriteMs, r.smartWriteMs, r.writeImprovementPct,
                    r.standardSeqReadMs, r.smartSeqReadMs, r.seqReadOverheadPct,
                    r.standardRandomReadMs, r.smartRandomReadMs, r.randomReadOverheadPct,
                    r.containerOpenTimeMs, r.indexLookupTimeMs, r.positionSeekTimeMs, r.avgSeekTimeMs,
                    r.standardMemoryBytes, r.smartMemoryBytes, r.memorySavingsPct,
                    r.containerCount, r.aggregationRatio, r.indexSizeBytes, r.cacheHitRatio, r.indexOverheadPct));
        }
        
        return csv.toString();
    }
    
    // Inner classes for results
    
    public static class IndexEntry {
        public final int containerId;
        public final long offset;
        public final int length;
        
        public IndexEntry(int containerId, long offset, int length) {
            this.containerId = containerId;
            this.offset = offset;
            this.length = length;
        }
    }
    
    public static class SmartWriteResult {
        public final double timeMs;
        public final int containerCount;
        
        public SmartWriteResult(double timeMs, int containerCount) {
            this.timeMs = timeMs;
            this.containerCount = containerCount;
        }
    }
    
    public static class SeekTimeResult {
        public final double totalTimeMs;
        public final double containerOpenTimeMs;
        public final double indexLookupTimeMs;
        public final double positionSeekTimeMs;
        
        public SeekTimeResult(double totalTimeMs, double containerOpenTimeMs, 
                             double indexLookupTimeMs, double positionSeekTimeMs) {
            this.totalTimeMs = totalTimeMs;
            this.containerOpenTimeMs = containerOpenTimeMs;
            this.indexLookupTimeMs = indexLookupTimeMs;
            this.positionSeekTimeMs = positionSeekTimeMs;
        }
    }
    
    public static class EnhancedResult {
        public final Date timestamp;
        public final int fileCount;
        public final int avgFileSizeKb;
        public final double standardWriteMs;
        public final double smartWriteMs;
        public final double writeImprovementPct;
        public final double standardSeqReadMs;
        public final double smartSeqReadMs;
        public final double seqReadOverheadPct;
        public final double standardRandomReadMs;
        public final double smartRandomReadMs;
        public final double randomReadOverheadPct;
        public final double containerOpenTimeMs;
        public final double indexLookupTimeMs;
        public final double positionSeekTimeMs;
        public final double avgSeekTimeMs;
        public final long standardMemoryBytes;
        public final long smartMemoryBytes;
        public final double memorySavingsPct;
        public final int containerCount;
        public final double aggregationRatio;
        public final long indexSizeBytes;
        public final double cacheHitRatio;
        public final double indexOverheadPct;
        
        public EnhancedResult(Date timestamp, int fileCount, int avgFileSizeKb,
                             double standardWriteMs, double smartWriteMs, double writeImprovementPct,
                             double standardSeqReadMs, double smartSeqReadMs, double seqReadOverheadPct,
                             double standardRandomReadMs, double smartRandomReadMs, double randomReadOverheadPct,
                             double containerOpenTimeMs, double indexLookupTimeMs, double positionSeekTimeMs,
                             double avgSeekTimeMs, long standardMemoryBytes, long smartMemoryBytes,
                             double memorySavingsPct, int containerCount, double aggregationRatio,
                             long indexSizeBytes, double cacheHitRatio, double indexOverheadPct) {
            this.timestamp = timestamp;
            this.fileCount = fileCount;
            this.avgFileSizeKb = avgFileSizeKb;
            this.standardWriteMs = standardWriteMs;
            this.smartWriteMs = smartWriteMs;
            this.writeImprovementPct = writeImprovementPct;
            this.standardSeqReadMs = standardSeqReadMs;
            this.smartSeqReadMs = smartSeqReadMs;
            this.seqReadOverheadPct = seqReadOverheadPct;
            this.standardRandomReadMs = standardRandomReadMs;
            this.smartRandomReadMs = smartRandomReadMs;
            this.randomReadOverheadPct = randomReadOverheadPct;
            this.containerOpenTimeMs = containerOpenTimeMs;
            this.indexLookupTimeMs = indexLookupTimeMs;
            this.positionSeekTimeMs = positionSeekTimeMs;
            this.avgSeekTimeMs = avgSeekTimeMs;
            this.standardMemoryBytes = standardMemoryBytes;
            this.smartMemoryBytes = smartMemoryBytes;
            this.memorySavingsPct = memorySavingsPct;
            this.containerCount = containerCount;
            this.aggregationRatio = aggregationRatio;
            this.indexSizeBytes = indexSizeBytes;
            this.cacheHitRatio = cacheHitRatio;
            this.indexOverheadPct = indexOverheadPct;
        }
    }
}
