package com.smarthdfs.benchmark;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Benchmark Runner - Measures and compares performance of different write strategies.
 * 
 * This class provides comprehensive benchmarking capabilities for evaluating
 * the Smart HDFS Client against standard HDFS operations.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class BenchmarkRunner {
    
    private final List<BenchmarkResult> results;
    private final AtomicLong totalWriteTime;
    private final AtomicLong totalReadTime;
    private final AtomicLong totalBytesWritten;
    private final AtomicLong totalBytesRead;
    private final AtomicLong totalFilesProcessed;
    
    // Memory tracking
    private long initialMemory;
    private long peakMemory;
    private long finalMemory;
    
    /**
     * Constructor for BenchmarkRunner
     */
    public BenchmarkRunner() {
        this.results = new ArrayList<>();
        this.totalWriteTime = new AtomicLong(0);
        this.totalReadTime = new AtomicLong(0);
        this.totalBytesWritten = new AtomicLong(0);
        this.totalBytesRead = new AtomicLong(0);
        this.totalFilesProcessed = new AtomicLong(0);
    }
    
    /**
     * Start memory tracking
     */
    public void startMemoryTracking() {
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        initialMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        peakMemory = initialMemory;
    }
    
    /**
     * Update peak memory
     */
    public void updatePeakMemory() {
        long currentMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        peakMemory = Math.max(peakMemory, currentMemory);
    }
    
    /**
     * Stop memory tracking
     */
    public void stopMemoryTracking() {
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        finalMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    }
    
    /**
     * Record a benchmark result
     * 
     * @param operation The operation name
     * @param durationMs The duration in milliseconds
     * @param bytesProcessed The number of bytes processed
     * @param success Whether the operation succeeded
     */
    public void recordResult(String operation, long durationMs, long bytesProcessed, boolean success) {
        BenchmarkResult result = new BenchmarkResult(
                operation,
                durationMs,
                bytesProcessed,
                success,
                System.currentTimeMillis()
        );
        results.add(result);
        
        if (operation.contains("write")) {
            totalWriteTime.addAndGet(durationMs);
            totalBytesWritten.addAndGet(bytesProcessed);
        } else if (operation.contains("read")) {
            totalReadTime.addAndGet(durationMs);
            totalBytesRead.addAndGet(bytesProcessed);
        }
        totalFilesProcessed.incrementAndGet();
        
        updatePeakMemory();
    }
    
    /**
     * Run a benchmark with automatic timing
     * 
     * @param operation The operation name
     * @param runnable The operation to run
     * @param bytesProcessed The number of bytes processed
     * @return The duration in milliseconds
     */
    public long runBenchmark(String operation, Runnable runnable, long bytesProcessed) {
        long startTime = System.currentTimeMillis();
        boolean success = true;
        
        try {
            runnable.run();
        } catch (Exception e) {
            success = false;
            System.err.println("Benchmark failed: " + operation + " - " + e.getMessage());
        }
        
        long duration = System.currentTimeMillis() - startTime;
        recordResult(operation, duration, bytesProcessed, success);
        
        return duration;
    }
    
    /**
     * Run a benchmark with return value
     * 
     * @param operation The operation name
     * @param supplier The operation to run
     * @param bytesProcessed The number of bytes processed
     * @return The benchmark result with return value
     */
    public <T> BenchmarkResultWithValue<T> runBenchmarkWithResult(
            String operation, BenchmarkSupplier<T> supplier, long bytesProcessed) {
        
        long startTime = System.currentTimeMillis();
        T result = null;
        boolean success = true;
        
        try {
            result = supplier.get();
        } catch (Exception e) {
            success = false;
            System.err.println("Benchmark failed: " + operation + " - " + e.getMessage());
        }
        
        long duration = System.currentTimeMillis() - startTime;
        recordResult(operation, duration, bytesProcessed, success);
        
        return new BenchmarkResultWithValue<>(operation, duration, bytesProcessed, success, result);
    }
    
    /**
     * Calculate throughput (bytes per second)
     * 
     * @param bytes The number of bytes
     * @param durationMs The duration in milliseconds
     * @return Throughput in bytes per second
     */
    public static double calculateThroughput(long bytes, long durationMs) {
        if (durationMs == 0) return 0;
        return (bytes * 1000.0) / durationMs;
    }
    
    /**
     * Calculate operations per second
     * 
     * @param count The number of operations
     * @param durationMs The duration in milliseconds
     * @return Operations per second
     */
    public static double calculateOpsPerSecond(long count, long durationMs) {
        if (durationMs == 0) return 0;
        return (count * 1000.0) / durationMs;
    }
    
    /**
     * Get summary statistics
     * 
     * @return Map of statistics
     */
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new ConcurrentHashMap<>();
        
        // Write statistics
        stats.put("totalWriteTimeMs", totalWriteTime.get());
        stats.put("totalBytesWritten", totalBytesWritten.get());
        stats.put("writeThroughputBps", calculateThroughput(totalBytesWritten.get(), totalWriteTime.get()));
        
        // Read statistics
        stats.put("totalReadTimeMs", totalReadTime.get());
        stats.put("totalBytesRead", totalBytesRead.get());
        stats.put("readThroughputBps", calculateThroughput(totalBytesRead.get(), totalReadTime.get()));
        
        // File statistics
        stats.put("totalFilesProcessed", totalFilesProcessed.get());
        stats.put("opsPerSecond", calculateOpsPerSecond(totalFilesProcessed.get(), 
                totalWriteTime.get() + totalReadTime.get()));
        
        // Memory statistics
        stats.put("initialMemoryBytes", initialMemory);
        stats.put("peakMemoryBytes", peakMemory);
        stats.put("finalMemoryBytes", finalMemory);
        stats.put("memoryUsedBytes", peakMemory - initialMemory);
        
        return stats;
    }
    
    /**
     * Generate a detailed report
     * 
     * @return Formatted report string
     */
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        
        report.append("\n");
        report.append("╔════════════════════════════════════════════════════════════════╗\n");
        report.append("║                    BENCHMARK RESULTS REPORT                     ║\n");
        report.append("╚════════════════════════════════════════════════════════════════╝\n");
        report.append("\n");
        
        Map<String, Object> stats = getStatistics();
        
        report.append("┌─────────────────────────────────────────────────────────────────┐\n");
        report.append("│ WRITE PERFORMANCE                                               │\n");
        report.append("├─────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Total Write Time:      %,d ms%n", stats.get("totalWriteTimeMs")));
        report.append(String.format("│ Total Bytes Written:   %,d bytes%n", stats.get("totalBytesWritten")));
        report.append(String.format("│ Write Throughput:      %,.2f MB/s%n", 
                (double) stats.get("writeThroughputBps") / (1024 * 1024)));
        report.append("└─────────────────────────────────────────────────────────────────┘\n");
        report.append("\n");
        
        report.append("┌─────────────────────────────────────────────────────────────────┐\n");
        report.append("│ READ PERFORMANCE                                                │\n");
        report.append("├─────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Total Read Time:       %,d ms%n", stats.get("totalReadTimeMs")));
        report.append(String.format("│ Total Bytes Read:      %,d bytes%n", stats.get("totalBytesRead")));
        report.append(String.format("│ Read Throughput:       %,.2f MB/s%n", 
                (double) stats.get("readThroughputBps") / (1024 * 1024)));
        report.append("└─────────────────────────────────────────────────────────────────┘\n");
        report.append("\n");
        
        report.append("┌─────────────────────────────────────────────────────────────────┐\n");
        report.append("│ MEMORY USAGE                                                    │\n");
        report.append("├─────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Initial Memory:        %,.2f MB%n", 
                (long) stats.get("initialMemoryBytes") / (1024.0 * 1024)));
        report.append(String.format("│ Peak Memory:           %,.2f MB%n", 
                (long) stats.get("peakMemoryBytes") / (1024.0 * 1024)));
        report.append(String.format("│ Memory Used:           %,.2f MB%n", 
                (long) stats.get("memoryUsedBytes") / (1024.0 * 1024)));
        report.append("└─────────────────────────────────────────────────────────────────┘\n");
        report.append("\n");
        
        report.append("┌─────────────────────────────────────────────────────────────────┐\n");
        report.append("│ OVERALL STATISTICS                                              │\n");
        report.append("├─────────────────────────────────────────────────────────────────┤\n");
        report.append(String.format("│ Total Files Processed: %,d%n", stats.get("totalFilesProcessed")));
        report.append(String.format("│ Operations/sec:        %,.2f%n", stats.get("opsPerSecond")));
        report.append("└─────────────────────────────────────────────────────────────────┘\n");
        
        return report.toString();
    }
    
    /**
     * Export results to CSV format
     * 
     * @return CSV string
     */
    public String exportToCsv() {
        StringBuilder csv = new StringBuilder();
        csv.append("operation,duration_ms,bytes_processed,success,timestamp\n");
        
        for (BenchmarkResult result : results) {
            csv.append(String.format("%s,%d,%d,%b,%d\n",
                    result.getOperation(),
                    result.getDurationMs(),
                    result.getBytesProcessed(),
                    result.isSuccess(),
                    result.getTimestamp()
            ));
        }
        
        return csv.toString();
    }
    
    /**
     * Reset the benchmark runner
     */
    public void reset() {
        results.clear();
        totalWriteTime.set(0);
        totalReadTime.set(0);
        totalBytesWritten.set(0);
        totalBytesRead.set(0);
        totalFilesProcessed.set(0);
        initialMemory = 0;
        peakMemory = 0;
        finalMemory = 0;
    }
    
    /**
     * Functional interface for benchmark supplier
     */
    @FunctionalInterface
    public interface BenchmarkSupplier<T> {
        T get() throws Exception;
    }
    
    /**
     * Inner class for benchmark results
     */
    public static class BenchmarkResult {
        private final String operation;
        private final long durationMs;
        private final long bytesProcessed;
        private final boolean success;
        private final long timestamp;
        
        public BenchmarkResult(String operation, long durationMs, long bytesProcessed, 
                              boolean success, long timestamp) {
            this.operation = operation;
            this.durationMs = durationMs;
            this.bytesProcessed = bytesProcessed;
            this.success = success;
            this.timestamp = timestamp;
        }
        
        public String getOperation() { return operation; }
        public long getDurationMs() { return durationMs; }
        public long getBytesProcessed() { return bytesProcessed; }
        public boolean isSuccess() { return success; }
        public long getTimestamp() { return timestamp; }
    }
    
    /**
     * Inner class for benchmark results with return value
     */
    public static class BenchmarkResultWithValue<T> extends BenchmarkResult {
        private final T value;
        
        public BenchmarkResultWithValue(String operation, long durationMs, 
                                        long bytesProcessed, boolean success, T value) {
            super(operation, durationMs, bytesProcessed, success, System.currentTimeMillis());
            this.value = value;
        }
        
        public T getValue() { return value; }
    }
}
