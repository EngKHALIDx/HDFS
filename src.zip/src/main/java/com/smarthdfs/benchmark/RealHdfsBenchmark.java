package com.smarthdfs.benchmark;

import com.smarthdfs.client.SmartHdfsClient;
import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Real HDFS Benchmark - Tests performance against actual HDFS cluster.
 * 
 * This benchmark connects to a real HDFS cluster and measures:
 * 1. Write performance (Standard HDFS vs Smart HDFS Client)
 * 2. Read performance (Sequential and Random)
 * 3. Memory usage on NameNode
 * 4. Seek time overhead for aggregated containers
 * 
 * Usage:
 * <pre>
 * RealHdfsBenchmark benchmark = new RealHdfsBenchmark("hdfs://namenode:9000");
 * benchmark.runFullBenchmark(1000, 50 * 1024); // 1000 files, 50KB each
 * </pre>
 * 
 * @author Khaled Abdullah Mohammed Hussein Al-Kholani
 * @version 1.0.0
 */
public class RealHdfsBenchmark {
    
    private static final Logger LOG = LoggerFactory.getLogger(RealHdfsBenchmark.class);
    
    private final String hdfsUri;
    private final Configuration hadoopConfig;
    
    // Statistics
    private final List<BenchmarkResult> results;
    
    /**
     * Constructor
     * 
     * @param hdfsUri The HDFS URI (e.g., "hdfs://namenode:9000")
     */
    public RealHdfsBenchmark(String hdfsUri) {
        this.hdfsUri = hdfsUri;
        this.hadoopConfig = new Configuration();
        this.results = new ArrayList<>();
        
        // Configure Hadoop
        hadoopConfig.set("fs.defaultFS", hdfsUri);
        hadoopConfig.set("dfs.client.use.datanode.hostname", "true");
        hadoopConfig.setInt("dfs.replication", 1);
    }
    
    /**
     * Run a full benchmark comparing Standard HDFS vs Smart HDFS Client
     * 
     * @param fileCount Number of files to test
     * @param fileSizeBytes Size of each file in bytes
     * @return Benchmark results
     */
    public BenchmarkResult runFullBenchmark(int fileCount, int fileSizeBytes) throws IOException {
        LOG.info("========================================");
        LOG.info("Starting Benchmark: {} files, {} bytes each", fileCount, fileSizeBytes);
        LOG.info("========================================");
        
        BenchmarkResult result = new BenchmarkResult();
        result.fileCount = fileCount;
        result.fileSizeBytes = fileSizeBytes;
        result.timestamp = new Date();
        
        // Generate test data
        byte[][] testData = generateTestData(fileCount, fileSizeBytes);
        
        // Create test directories
        String testDir = "/benchmark_" + System.currentTimeMillis();
        String standardDir = testDir + "/standard";
        String smartDir = testDir + "/smart";
        
        try {
            // ============================================
            // STANDARD HDFS BENCHMARK
            // ============================================
            LOG.info("\n--- Standard HDFS Write Benchmark ---");
            result.standardWriteTimeMs = benchmarkStandardWrite(standardDir, testData);
            result.standardWriteThroughput = calculateThroughput(fileCount * fileSizeBytes, result.standardWriteTimeMs);
            
            LOG.info("\n--- Standard HDFS Read Benchmark ---");
            result.standardSequentialReadMs = benchmarkStandardSequentialRead(standardDir, fileCount);
            result.standardRandomReadMs = benchmarkStandardRandomRead(standardDir, fileCount);
            
            // ============================================
            // SMART HDFS CLIENT BENCHMARK
            // ============================================
            LOG.info("\n--- Smart HDFS Client Write Benchmark ---");
            SmartHdfsWriteResult smartWriteResult = benchmarkSmartWrite(smartDir, testData);
            result.smartWriteTimeMs = smartWriteResult.timeMs;
            result.containerCount = smartWriteResult.containerCount;
            result.smartWriteThroughput = calculateThroughput(fileCount * fileSizeBytes, result.smartWriteTimeMs);
            
            LOG.info("\n--- Smart HDFS Client Read Benchmark ---");
            result.smartSequentialReadMs = benchmarkSmartSequentialRead(smartDir, fileCount);
            
            SmartHdfsRandomReadResult randomReadResult = benchmarkSmartRandomRead(smartDir, fileCount);
            result.smartRandomReadMs = randomReadResult.timeMs;
            result.seekTimeMs = randomReadResult.seekTimeMs;
            result.indexLookupTimeMs = randomReadResult.indexLookupTimeMs;
            
            // ============================================
            // CALCULATE IMPROVEMENTS
            // ============================================
            result.writeImprovementPct = ((result.standardWriteTimeMs - result.smartWriteTimeMs) / 
                                          (double) result.standardWriteTimeMs) * 100;
            
            result.sequentialReadOverheadPct = ((result.smartSequentialReadMs - result.standardSequentialReadMs) / 
                                                (double) result.standardSequentialReadMs) * 100;
            
            result.randomReadOverheadPct = ((result.smartRandomReadMs - result.standardRandomReadMs) / 
                                            (double) result.standardRandomReadMs) * 100;
            
            // Calculate memory savings (estimation)
            long standardMemory = (long) fileCount * 150; // 150 bytes per file
            long smartMemory = (long) result.containerCount * 150;
            result.memorySavingsPct = ((standardMemory - smartMemory) / (double) standardMemory) * 100;
            result.aggregationRatio = (double) fileCount / result.containerCount;
            
        } finally {
            // Cleanup
            cleanup(testDir);
        }
        
        results.add(result);
        return result;
    }
    
    /**
     * Benchmark standard HDFS write
     */
    private long benchmarkStandardWrite(String dir, byte[][] data) throws IOException {
        FileSystem fs = FileSystem.get(java.net.URI.create(hdfsUri), hadoopConfig);
        fs.mkdirs(new Path(dir));
        
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < data.length; i++) {
            Path filePath = new Path(dir, "file_" + i + ".dat");
            try (FSDataOutputStream out = fs.create(filePath)) {
                out.write(data[i]);
            }
            
            if ((i + 1) % 100 == 0) {
                LOG.info("Standard HDFS: Written {}/{} files", i + 1, data.length);
            }
        }
        
        long endTime = System.currentTimeMillis();
        fs.close();
        
        long duration = endTime - startTime;
        LOG.info("Standard HDFS write completed: {} ms for {} files", duration, data.length);
        return duration;
    }
    
    /**
     * Benchmark standard HDFS sequential read
     */
    private long benchmarkStandardSequentialRead(String dir, int fileCount) throws IOException {
        FileSystem fs = FileSystem.get(java.net.URI.create(hdfsUri), hadoopConfig);
        
        byte[] buffer = new byte[4096];
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < fileCount; i++) {
            Path filePath = new Path(dir, "file_" + i + ".dat");
            try (FSDataInputStream in = fs.open(filePath)) {
                while (in.read(buffer) > 0) {
                    // Just read the data
                }
            }
        }
        
        long endTime = System.currentTimeMillis();
        fs.close();
        
        long duration = endTime - startTime;
        LOG.info("Standard HDFS sequential read completed: {} ms", duration);
        return duration;
    }
    
    /**
     * Benchmark standard HDFS random read
     */
    private long benchmarkStandardRandomRead(String dir, int fileCount) throws IOException {
        FileSystem fs = FileSystem.get(java.net.URI.create(hdfsUri), hadoopConfig);
        
        Random random = new Random(42);
        byte[] buffer = new byte[4096];
        int sampleSize = Math.min(100, fileCount);
        
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < sampleSize; i++) {
            int fileIdx = random.nextInt(fileCount);
            Path filePath = new Path(dir, "file_" + fileIdx + ".dat");
            try (FSDataInputStream in = fs.open(filePath)) {
                while (in.read(buffer) > 0) {
                    // Just read the data
                }
            }
        }
        
        long endTime = System.currentTimeMillis();
        fs.close();
        
        long duration = endTime - startTime;
        LOG.info("Standard HDFS random read completed: {} ms for {} samples", duration, sampleSize);
        return duration;
    }
    
    /**
     * Benchmark Smart HDFS Client write
     */
    private SmartHdfsWriteResult benchmarkSmartWrite(String dir, byte[][] data) throws IOException {
        SmartHdfsConfig config = SmartHdfsConfig.builder()
            .smallFileThreshold(128 * 1024 * 1024)
            .bufferSize(64 * 1024 * 1024)
            .enableAutoFlush(true)
            .containerDir("/smart-containers")
            .build();
        
        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, hadoopConfig);
        client.mkdirs(new Path(dir));
        
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < data.length; i++) {
            java.io.OutputStream out = client.create(new Path(dir, "file_" + i + ".dat"));
            out.write(data[i]);
            out.close();
            
            if ((i + 1) % 100 == 0) {
                LOG.info("Smart HDFS: Written {}/{} files", i + 1, data.length);
            }
        }
        
        // Force flush remaining files
        client.flush();
        
        long endTime = System.currentTimeMillis();
        
        // Get statistics
        Map<String, Object> stats = client.getStatistics();
        @SuppressWarnings("unchecked")
        Map<String, Long> aggStats = (Map<String, Long>) stats.get("aggregator");
        long containerCount = aggStats.getOrDefault("totalFilesFlushed", 0L) / 100 + 1;
        
        client.close();
        
        SmartHdfsWriteResult result = new SmartHdfsWriteResult();
        result.timeMs = endTime - startTime;
        result.containerCount = (int) containerCount;
        
        LOG.info("Smart HDFS write completed: {} ms for {} files", result.timeMs, data.length);
        return result;
    }
    
    /**
     * Benchmark Smart HDFS Client sequential read
     */
    private long benchmarkSmartSequentialRead(String dir, int fileCount) throws IOException {
        SmartHdfsConfig config = SmartHdfsConfig.builder()
            .smallFileThreshold(128 * 1024 * 1024)
            .bufferSize(64 * 1024 * 1024)
            .build();
        
        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, hadoopConfig);
        
        byte[] buffer = new byte[4096];
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < fileCount; i++) {
            try (FSDataInputStream in = client.open(new Path(dir, "file_" + i + ".dat"))) {
                while (in.read(buffer) > 0) {
                    // Just read the data
                }
            }
        }
        
        long endTime = System.currentTimeMillis();
        client.close();
        
        long duration = endTime - startTime;
        LOG.info("Smart HDFS sequential read completed: {} ms", duration);
        return duration;
    }
    
    /**
     * Benchmark Smart HDFS Client random read with seek time measurement
     */
    private SmartHdfsRandomReadResult benchmarkSmartRandomRead(String dir, int fileCount) throws IOException {
        SmartHdfsConfig config = SmartHdfsConfig.builder()
            .smallFileThreshold(128 * 1024 * 1024)
            .bufferSize(64 * 1024 * 1024)
            .build();
        
        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, hadoopConfig);
        
        Random random = new Random(42);
        byte[] buffer = new byte[4096];
        int sampleSize = Math.min(100, fileCount);
        
        long totalSeekTime = 0;
        long totalIndexTime = 0;
        
        long startTime = System.currentTimeMillis();
        
        for (int i = 0; i < sampleSize; i++) {
            int fileIdx = random.nextInt(fileCount);
            
            // Measure seek time (including index lookup)
            long seekStart = System.nanoTime();
            
            try (FSDataInputStream in = client.open(new Path(dir, "file_" + fileIdx + ".dat"))) {
                long seekEnd = System.nanoTime();
                totalSeekTime += (seekEnd - seekStart) / 1_000_000; // Convert to ms
                
                while (in.read(buffer) > 0) {
                    // Just read the data
                }
            }
        }
        
        long endTime = System.currentTimeMillis();
        client.close();
        
        SmartHdfsRandomReadResult result = new SmartHdfsRandomReadResult();
        result.timeMs = endTime - startTime;
        result.seekTimeMs = totalSeekTime;
        result.indexLookupTimeMs = totalIndexTime;
        
        LOG.info("Smart HDFS random read completed: {} ms for {} samples (seek time: {} ms)", 
                 result.timeMs, sampleSize, result.seekTimeMs);
        return result;
    }
    
    /**
     * Generate random test data
     */
    private byte[][] generateTestData(int count, int size) {
        Random random = new Random(42);
        byte[][] data = new byte[count][];
        
        for (int i = 0; i < count; i++) {
            data[i] = new byte[size];
            random.nextBytes(data[i]);
        }
        
        LOG.info("Generated {} test files of {} bytes each", count, size);
        return data;
    }
    
    /**
     * Calculate throughput in MB/s
     */
    private double calculateThroughput(long totalBytes, long durationMs) {
        if (durationMs == 0) return 0;
        double mb = totalBytes / (1024.0 * 1024.0);
        double seconds = durationMs / 1000.0;
        return mb / seconds;
    }
    
    /**
     * Cleanup test directory
     */
    private void cleanup(String dir) throws IOException {
        FileSystem fs = FileSystem.get(java.net.URI.create(hdfsUri), hadoopConfig);
        fs.delete(new Path(dir), true);
        fs.delete(new Path("/smart-containers"), true);
        fs.close();
        LOG.info("Cleaned up test directory: {}", dir);
    }
    
    /**
     * Generate a report of all benchmark results
     */
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        
        report.append("\n");
        report.append("╔════════════════════════════════════════════════════════════════════════════════╗\n");
        report.append("║                    REAL HDFS BENCHMARK RESULTS                                 ║\n");
        report.append("║              Standard HDFS vs Smart HDFS Client                                ║\n");
        report.append("╚════════════════════════════════════════════════════════════════════════════════╝\n");
        report.append("\n");
        
        report.append(String.format("%-15s %-12s %-15s %-15s %-15s %-15s%n",
                "Files", "Size(KB)", "Std Write(ms)", "Smart Write(ms)", "Improve%", "Containers"));
        report.append("-".repeat(90)).append("\n");
        
        for (BenchmarkResult r : results) {
            report.append(String.format("%-15,d %-12d %-15,.1f %-15,.1f %-15.1f %-15d%n",
                    r.fileCount, r.fileSizeBytes / 1024,
                    r.standardWriteTimeMs, r.smartWriteTimeMs,
                    r.writeImprovementPct, r.containerCount));
        }
        
        report.append("\n");
        report.append("Read Performance:\n");
        report.append(String.format("%-15s %-12s %-15s %-15s %-15s%n",
                "Files", "Read Type", "Std(ms)", "Smart(ms)", "Overhead%"));
        report.append("-".repeat(75)).append("\n");
        
        for (BenchmarkResult r : results) {
            report.append(String.format("%-15,d %-12s %-15,.1f %-15,.1f %-15.1f%n",
                    r.fileCount, "Sequential",
                    r.standardSequentialReadMs, r.smartSequentialReadMs,
                    r.sequentialReadOverheadPct));
            report.append(String.format("%-15d %-12s %-15,.1f %-15,.1f %-15.1f%n",
                    r.fileCount, "Random",
                    r.standardRandomReadMs, r.smartRandomReadMs,
                    r.randomReadOverheadPct));
        }
        
        return report.toString();
    }
    
    // Result classes
    private static class SmartHdfsWriteResult {
        long timeMs;
        int containerCount;
    }
    
    private static class SmartHdfsRandomReadResult {
        long timeMs;
        long seekTimeMs;
        long indexLookupTimeMs;
    }
    
    /**
     * Benchmark result data class
     */
    public static class BenchmarkResult {
        public Date timestamp;
        public int fileCount;
        public int fileSizeBytes;
        
        // Write performance
        public long standardWriteTimeMs;
        public long smartWriteTimeMs;
        public double writeImprovementPct;
        public double standardWriteThroughput;
        public double smartWriteThroughput;
        
        // Read performance
        public long standardSequentialReadMs;
        public long smartSequentialReadMs;
        public double sequentialReadOverheadPct;
        
        public long standardRandomReadMs;
        public long smartRandomReadMs;
        public double randomReadOverheadPct;
        
        public long seekTimeMs;
        public long indexLookupTimeMs;
        
        // Memory and aggregation
        public int containerCount;
        public double aggregationRatio;
        public double memorySavingsPct;
    }
    
    /**
     * Main method for command-line execution
     */
    public static void main(String[] args) throws Exception {
        String hdfsUri = args.length > 0 ? args[0] : "hdfs://localhost:9000";
        
        System.out.println("Real HDFS Benchmark");
        System.out.println("Connecting to: " + hdfsUri);
        
        RealHdfsBenchmark benchmark = new RealHdfsBenchmark(hdfsUri);
        
        // Run benchmarks with different file counts
        benchmark.runFullBenchmark(100, 50 * 1024);    // 100 files, 50KB each
        benchmark.runFullBenchmark(500, 50 * 1024);    // 500 files
        benchmark.runFullBenchmark(1000, 50 * 1024);   // 1000 files
        
        System.out.println(benchmark.generateReport());
    }
}
