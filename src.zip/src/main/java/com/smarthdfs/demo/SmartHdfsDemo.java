package com.smarthdfs.demo;

import com.smarthdfs.benchmark.BenchmarkRunner;
import com.smarthdfs.benchmark.PerformanceComparison;
import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.simulator.IoTDataSimulator;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Demo Application - Demonstrates the Smart HDFS Client capabilities.
 * 
 * This application simulates an IoT data ingestion scenario and shows
 * how the Smart HDFS Client transparently handles small file aggregation.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class SmartHdfsDemo {
    
    private static final int DEFAULT_FILE_COUNT = 1000;
    private static final int DEFAULT_READINGS_PER_FILE = 5;
    private static final String OUTPUT_DIR = "demo_output";
    
    private final IoTDataSimulator simulator;
    private final SmartHdfsConfig config;
    private final BenchmarkRunner benchmark;
    
    // Simulation state
    private final Map<String, byte[]> fileStorage; // Simulated HDFS storage
    private final Map<String, String> indexMap;    // File name -> container name mapping
    private final List<byte[]> containers;          // Container files
    private final AtomicInteger containerCounter;
    
    private long totalBytesWritten;
    private long totalFilesWritten;
    
    /**
     * Constructor for SmartHdfsDemo
     * 
     * @param config The configuration
     */
    public SmartHdfsDemo(SmartHdfsConfig config) {
        this.config = config;
        this.simulator = new IoTDataSimulator();
        this.benchmark = new BenchmarkRunner();
        
        this.fileStorage = new ConcurrentHashMap<>();
        this.indexMap = new ConcurrentHashMap<>();
        this.containers = new ArrayList<>();
        this.containerCounter = new AtomicInteger(0);
        
        this.totalBytesWritten = 0;
        this.totalFilesWritten = 0;
    }
    
    /**
     * Run the demo with default settings
     */
    public void runDemo() {
        runDemo(DEFAULT_FILE_COUNT, DEFAULT_READINGS_PER_FILE);
    }
    
    /**
     * Run the demo with custom settings
     * 
     * @param fileCount Number of files to generate
     * @param readingsPerFile Number of sensor readings per file
     */
    public void runDemo(int fileCount, int readingsPerFile) {
        printHeader();
        
        System.out.println("Configuration:");
        System.out.println("  File Count: " + fileCount);
        System.out.println("  Readings per File: " + readingsPerFile);
        System.out.println("  Small File Threshold: " + formatSize(config.getSmallFileThreshold()));
        System.out.println("  Buffer Size: " + formatSize(config.getBufferSize()));
        System.out.println();
        
        // Generate data
        System.out.println("=== Phase 1: Generating IoT Data ===");
        byte[][] dataFiles = simulator.generateDataFiles(fileCount, readingsPerFile);
        System.out.println(simulator.getDataStatistics(dataFiles));
        System.out.println();
        
        // Write using Smart Client
        System.out.println("=== Phase 2: Writing with Smart HDFS Client ===");
        benchmark.startMemoryTracking();
        
        long writeStart = System.currentTimeMillis();
        
        for (int i = 0; i < dataFiles.length; i++) {
            String fileName = simulator.generateFileName(i);
            writeWithSmartClient(fileName, dataFiles[i]);
        }
        
        // Flush remaining buffer
        flushBuffer();
        
        long writeEnd = System.currentTimeMillis();
        benchmark.stopMemoryTracking();
        
        System.out.println();
        System.out.println("Write Results:");
        System.out.println("  Total Write Time: " + (writeEnd - writeStart) + " ms");
        System.out.println("  Total Files Written: " + totalFilesWritten);
        System.out.println("  Total Bytes Written: " + formatSize(totalBytesWritten));
        System.out.println("  Container Files Created: " + containers.size());
        System.out.println("  Aggregation Ratio: " + String.format("%.1f:1", (double) totalFilesWritten / Math.max(1, containers.size())));
        System.out.println();
        
        // Calculate NameNode memory savings
        long standardNameNodeMemory = totalFilesWritten * 150; // 150 bytes per file
        long smartNameNodeMemory = containers.size() * 150;
        double savingsPercent = ((double) (standardNameNodeMemory - smartNameNodeMemory) / standardNameNodeMemory) * 100;
        
        System.out.println("=== Phase 3: NameNode Memory Impact ===");
        System.out.println("  Standard HDFS Memory: " + formatSize(standardNameNodeMemory));
        System.out.println("  Smart Client Memory: " + formatSize(smartNameNodeMemory));
        System.out.println("  Memory Savings: " + String.format("%.1f%%", savingsPercent));
        System.out.println();
        
        // Read test
        System.out.println("=== Phase 4: Reading Files ===");
        long readStart = System.currentTimeMillis();
        int successReads = 0;
        
        // Read a sample of files
        int sampleSize = Math.min(100, fileCount);
        for (int i = 0; i < sampleSize; i++) {
            String fileName = simulator.generateFileName(i);
            byte[] data = readWithSmartClient(fileName);
            if (data != null) {
                successReads++;
            }
        }
        
        long readEnd = System.currentTimeMillis();
        
        System.out.println("  Read Test: " + successReads + "/" + sampleSize + " files");
        System.out.println("  Read Time: " + (readEnd - readStart) + " ms");
        System.out.println();
        
        // Summary
        printSummary(fileCount, writeEnd - writeStart, savingsPercent);
        
        // Save demo output
        saveDemoOutput();
    }
    
    /**
     * Write a file using Smart Client simulation
     */
    private void writeWithSmartClient(String fileName, byte[] data) {
        // Check if file is small enough for aggregation
        if (data.length < config.getSmallFileThreshold()) {
            // Add to current buffer (simulated)
            String containerName = getCurrentContainerName();
            indexMap.put(fileName, containerName);
            fileStorage.put(fileName, data);
            totalBytesWritten += data.length;
            totalFilesWritten++;
            
            // Check if we should create a new container
            if (fileStorage.size() >= 100) { // 100 files per container
                flushBuffer();
            }
        } else {
            // Write large file directly
            fileStorage.put(fileName, data);
            totalBytesWritten += data.length;
            totalFilesWritten++;
        }
    }
    
    /**
     * Flush the current buffer to a container
     */
    private void flushBuffer() {
        if (fileStorage.isEmpty()) {
            return;
        }
        
        // Create a container from current files
        ByteArrayOutputStream containerStream = new ByteArrayOutputStream();
        
        for (Map.Entry<String, byte[]> entry : fileStorage.entrySet()) {
            try {
                // Write file entry header
                String header = String.format("FILE:%s:SIZE:%d\n", 
                        entry.getKey(), entry.getValue().length);
                containerStream.write(header.getBytes(StandardCharsets.UTF_8));
                containerStream.write(entry.getValue());
                containerStream.write('\n');
            } catch (IOException e) {
                // Ignore
            }
        }
        
        containers.add(containerStream.toByteArray());
        fileStorage.clear();
        containerCounter.incrementAndGet();
    }
    
    /**
     * Read a file using Smart Client simulation
     */
    private byte[] readWithSmartClient(String fileName) {
        // Check if file is in current buffer
        if (fileStorage.containsKey(fileName)) {
            return fileStorage.get(fileName);
        }
        
        // Check index for container location
        String containerName = indexMap.get(fileName);
        if (containerName != null) {
            // Find the container and extract the file
            int containerIndex = extractContainerIndex(containerName);
            if (containerIndex >= 0 && containerIndex < containers.size()) {
                byte[] containerData = containers.get(containerIndex);
                return extractFileFromContainer(containerData, fileName);
            }
        }
        
        return null;
    }
    
    /**
     * Extract container index from container name
     */
    private int extractContainerIndex(String containerName) {
        try {
            String numPart = containerName.replaceAll("[^0-9]", "");
            return Integer.parseInt(numPart) % Math.max(1, containers.size());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    
    /**
     * Extract a file from container data
     */
    private byte[] extractFileFromContainer(byte[] containerData, String fileName) {
        try {
            String dataStr = new String(containerData, StandardCharsets.UTF_8);
            String fileMarker = "FILE:" + fileName + ":SIZE:";
            int startIdx = dataStr.indexOf(fileMarker);
            
            if (startIdx >= 0) {
                int sizeStart = startIdx + fileMarker.length();
                int sizeEnd = dataStr.indexOf('\n', sizeStart);
                int size = Integer.parseInt(dataStr.substring(sizeStart, sizeEnd));
                
                int dataStart = sizeEnd + 1;
                byte[] result = new byte[size];
                System.arraycopy(containerData, dataStart, result, 0, size);
                return result;
            }
        } catch (Exception e) {
            // Ignore
        }
        return null;
    }
    
    /**
     * Get current container name
     */
    private String getCurrentContainerName() {
        return "container_" + containerCounter.get();
    }
    
    /**
     * Format byte size to human-readable format
     */
    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
    
    /**
     * Print demo header
     */
    private void printHeader() {
        System.out.println();
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║           Smart HDFS Client - Demo Application                  ║");
        System.out.println("║     Transparent Small Files Aggregation for HDFS                ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.println();
    }
    
    /**
     * Print summary
     */
    private void printSummary(int fileCount, long writeTime, double savingsPercent) {
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                       DEMO SUMMARY                              ║");
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.printf("║  Files Processed:      %,8d                               %n", fileCount);
        System.out.printf("║  Write Time:           %,8d ms                            %n", writeTime);
        System.out.printf("║  Memory Savings:       %,8.1f%%                            %n", savingsPercent);
        System.out.printf("║  Container Files:      %,8d                               %n", containers.size());
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.println();
    }
    
    /**
     * Save demo output to files
     */
    private void saveDemoOutput() {
        try {
            Path outputDir = Paths.get(OUTPUT_DIR);
            Files.createDirectories(outputDir);
            
            // Save sample container
            if (!containers.isEmpty()) {
                Path containerPath = outputDir.resolve("sample_container.bin");
                Files.write(containerPath, containers.get(0));
            }
            
            // Save index
            Path indexPath = outputDir.resolve("file_index.txt");
            try (BufferedWriter writer = Files.newBufferedWriter(indexPath)) {
                for (Map.Entry<String, String> entry : indexMap.entrySet()) {
                    writer.write(entry.getKey() + " -> " + entry.getValue() + "\n");
                }
            }
            
            // Save report
            Path reportPath = outputDir.resolve("demo_report.txt");
            try (BufferedWriter writer = Files.newBufferedWriter(reportPath)) {
                writer.write("Smart HDFS Client Demo Report\n");
                writer.write("=" + "=".repeat(50) + "\n\n");
                writer.write("Generated: " + Instant.now() + "\n\n");
                writer.write("Statistics:\n");
                writer.write("  Total Files: " + totalFilesWritten + "\n");
                writer.write("  Total Bytes: " + formatSize(totalBytesWritten) + "\n");
                writer.write("  Containers: " + containers.size() + "\n");
            }
            
            System.out.println("Demo output saved to: " + outputDir.toAbsolutePath());
            
        } catch (IOException e) {
            System.err.println("Failed to save demo output: " + e.getMessage());
        }
    }
    
    /**
     * Main entry point
     */
    public static void main(String[] args) {
        // Create configuration
        SmartHdfsConfig config = SmartHdfsConfig.builder()
                .blockSize(128 * 1024 * 1024)
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)
                .enableAutoFlush(true)
                .transparentMode(true)
                .build();
        
        // Create and run demo
        SmartHdfsDemo demo = new SmartHdfsDemo(config);
        
        int fileCount = DEFAULT_FILE_COUNT;
        int readingsPerFile = DEFAULT_READINGS_PER_FILE;
        
        // Parse command line arguments
        if (args.length >= 1) {
            try {
                fileCount = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid file count, using default: " + fileCount);
            }
        }
        
        if (args.length >= 2) {
            try {
                readingsPerFile = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid readings per file, using default: " + readingsPerFile);
            }
        }
        
        demo.runDemo(fileCount, readingsPerFile);
    }
}
