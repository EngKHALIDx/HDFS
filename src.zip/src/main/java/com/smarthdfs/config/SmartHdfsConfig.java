package com.smarthdfs.config;

import java.io.Serializable;

/**
 * Configuration class for Smart HDFS Client Library.
 * This class holds all configurable parameters for the small files aggregation system.
 * 
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class SmartHdfsConfig implements Serializable {
    
    private static final long serialVersionUID = 1L;

    // Default values
    public static final long DEFAULT_BLOCK_SIZE = 128 * 1024 * 1024; // 128 MB
    public static final long DEFAULT_SMALL_FILE_THRESHOLD = 128 * 1024 * 1024; // 128 MB
    public static final int DEFAULT_BUFFER_SIZE = 64 * 1024 * 1024; // 64 MB
    public static final long DEFAULT_FLUSH_INTERVAL_MS = 30000; // 30 seconds
    public static final String DEFAULT_CONTAINER_PREFIX = "smart_container_";
    public static final String DEFAULT_INDEX_SUFFIX = ".index";
    public static final String DEFAULT_CONTAINER_DIR = "/smart_hdfs/containers";
    
    // Configuration parameters
    private long blockSize;
    private long smallFileThreshold;
    private int bufferSize;
    private long flushIntervalMs;
    private String containerPrefix;
    private String indexSuffix;
    private String containerDir;
    private boolean enableAutoFlush;
    private boolean enableCompression;
    private CompressionType compressionType;
    private boolean enableIndexCache;
    private int indexCacheSize;
    private boolean transparentMode;
    
    /**
     * Enum for supported compression types
     */
    public enum CompressionType {
        NONE,
        SNAPPY,
        GZIP,
        LZO
    }
    
    /**
     * Default constructor with default values
     */
    public SmartHdfsConfig() {
        this.blockSize = DEFAULT_BLOCK_SIZE;
        this.smallFileThreshold = DEFAULT_SMALL_FILE_THRESHOLD;
        this.bufferSize = DEFAULT_BUFFER_SIZE;
        this.flushIntervalMs = DEFAULT_FLUSH_INTERVAL_MS;
        this.containerPrefix = DEFAULT_CONTAINER_PREFIX;
        this.indexSuffix = DEFAULT_INDEX_SUFFIX;
        this.containerDir = DEFAULT_CONTAINER_DIR;
        this.enableAutoFlush = true;
        this.enableCompression = false;
        this.compressionType = CompressionType.NONE;
        this.enableIndexCache = true;
        this.indexCacheSize = 10000;
        this.transparentMode = true;
    }
    
    /**
     * Builder pattern for easy configuration
     */
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private SmartHdfsConfig config = new SmartHdfsConfig();
        
        public Builder blockSize(long blockSize) {
            config.blockSize = blockSize;
            return this;
        }
        
        public Builder smallFileThreshold(long threshold) {
            config.smallFileThreshold = threshold;
            return this;
        }
        
        public Builder bufferSize(int bufferSize) {
            config.bufferSize = bufferSize;
            return this;
        }
        
        public Builder flushIntervalMs(long interval) {
            config.flushIntervalMs = interval;
            return this;
        }
        
        public Builder containerPrefix(String prefix) {
            config.containerPrefix = prefix;
            return this;
        }
        
        public Builder containerDir(String dir) {
            config.containerDir = dir;
            return this;
        }
        
        public Builder enableAutoFlush(boolean enable) {
            config.enableAutoFlush = enable;
            return this;
        }
        
        public Builder enableCompression(boolean enable) {
            config.enableCompression = enable;
            return this;
        }
        
        public Builder compressionType(CompressionType type) {
            config.compressionType = type;
            return this;
        }
        
        public Builder transparentMode(boolean enable) {
            config.transparentMode = enable;
            return this;
        }
        
        public SmartHdfsConfig build() {
            return config;
        }
    }
    
    // Getters
    public long getBlockSize() {
        return blockSize;
    }
    
    public long getSmallFileThreshold() {
        return smallFileThreshold;
    }
    
    public int getBufferSize() {
        return bufferSize;
    }
    
    public long getFlushIntervalMs() {
        return flushIntervalMs;
    }
    
    public String getContainerPrefix() {
        return containerPrefix;
    }
    
    public String getIndexSuffix() {
        return indexSuffix;
    }
    
    public String getContainerDir() {
        return containerDir;
    }
    
    public boolean isEnableAutoFlush() {
        return enableAutoFlush;
    }
    
    public boolean isEnableCompression() {
        return enableCompression;
    }
    
    public CompressionType getCompressionType() {
        return compressionType;
    }
    
    public boolean isEnableIndexCache() {
        return enableIndexCache;
    }
    
    public int getIndexCacheSize() {
        return indexCacheSize;
    }
    
    public boolean isTransparentMode() {
        return transparentMode;
    }
    
    // Setters
    public void setBlockSize(long blockSize) {
        this.blockSize = blockSize;
    }
    
    public void setSmallFileThreshold(long smallFileThreshold) {
        this.smallFileThreshold = smallFileThreshold;
    }
    
    public void setBufferSize(int bufferSize) {
        this.bufferSize = bufferSize;
    }
    
    public void setFlushIntervalMs(long flushIntervalMs) {
        this.flushIntervalMs = flushIntervalMs;
    }
    
    public void setContainerPrefix(String containerPrefix) {
        this.containerPrefix = containerPrefix;
    }
    
    public void setContainerDir(String containerDir) {
        this.containerDir = containerDir;
    }
    
    public void setEnableAutoFlush(boolean enableAutoFlush) {
        this.enableAutoFlush = enableAutoFlush;
    }
    
    public void setEnableCompression(boolean enableCompression) {
        this.enableCompression = enableCompression;
    }
    
    public void setCompressionType(CompressionType compressionType) {
        this.compressionType = compressionType;
    }
    
    public void setTransparentMode(boolean transparentMode) {
        this.transparentMode = transparentMode;
    }
    
    @Override
    public String toString() {
        return "SmartHdfsConfig{" +
                "blockSize=" + blockSize +
                ", smallFileThreshold=" + smallFileThreshold +
                ", bufferSize=" + bufferSize +
                ", flushIntervalMs=" + flushIntervalMs +
                ", containerDir='" + containerDir + '\'' +
                ", enableAutoFlush=" + enableAutoFlush +
                ", enableCompression=" + enableCompression +
                ", compressionType=" + compressionType +
                ", transparentMode=" + transparentMode +
                '}';
    }
}
