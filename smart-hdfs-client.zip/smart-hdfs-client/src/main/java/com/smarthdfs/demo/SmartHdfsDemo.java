package com.smarthdfs.demo;

import com.smarthdfs.client.SmartHdfsClient;
import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.MiniDFSCluster;

import java.io.OutputStream;
import java.util.Arrays;
import java.util.Random;

/**
 * SmartHdfsDemo - A REAL demonstration using Hadoop's MiniDFSCluster.
 *
 * <p>Starts an in-process HDFS cluster and uses the SmartHdfsClient to write
 * and read small files through real HDFS I/O (SequenceFile containers).
 * No HashMap simulation -- everything goes through the actual Hadoop FileSystem API.</p>
 *
 * <p>Usage: mvn exec:java -Dexec.mainClass="com.smarthdfs.demo.SmartHdfsDemo" -Dexec.args="[fileCount]"</p>
 *
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class SmartHdfsDemo {

    /** Default number of small files to generate. */
    private static final int DEFAULT_FILE_COUNT = 500;

    /** Minimum random file size in bytes (1 KB). */
    private static final int MIN_FILE_SIZE = 1 * 1024;

    /** Maximum random file size in bytes (10 KB). */
    private static final int MAX_FILE_SIZE = 10 * 1024;

    // --------------------------------------------------------------------- //
    //  Main entry point
    // --------------------------------------------------------------------- //

    public static void main(String[] args) throws Exception {
        int fileCount = DEFAULT_FILE_COUNT;
        if (args.length > 0) {
            try {
                fileCount = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Invalid file count argument, using default: " + DEFAULT_FILE_COUNT);
            }
        }

        new SmartHdfsDemo().run(fileCount);
    }

    // --------------------------------------------------------------------- //
    //  Demo logic
    // --------------------------------------------------------------------- //

    /**
     * Run the demo with the given number of files.
     *
     * @param fileCount number of small files to write and read back
     */
    public void run(int fileCount) throws Exception {
        System.out.println("================================================================");
        System.out.println("  Smart HDFS Client  -  Real HDFS Demo  (MiniDFSCluster)");
        System.out.println("================================================================\n");
        System.out.println("  Files to write : " + fileCount);
        System.out.println("  File size range: " + formatSize(MIN_FILE_SIZE) + " - " + formatSize(MAX_FILE_SIZE));
        System.out.println();

        // ---- 1. Start MiniDFSCluster (real HDFS) ----
        System.out.println("[1/5] Starting MiniDFSCluster ...");
        Configuration conf = new Configuration();
        MiniDFSCluster cluster = new MiniDFSCluster.Builder(conf)
                .format(true)
                .numDataNodes(1)
                .build();
        cluster.waitActive();

        String hdfsUri = cluster.getURI().toString();
        conf.set("fs.defaultFS", hdfsUri);
        System.out.println("       HDFS is active at: " + hdfsUri);

        try {
            // ---- 2. Create SmartHdfsClient ----
            System.out.println("[2/5] Creating SmartHdfsClient ...");

            String containerDir = "/smart_hdfs_demo/containers";
            SmartHdfsConfig smartConfig = SmartHdfsConfig.builder()
                    .smallFileThreshold(128 * 1024 * 1024)   // 128 MB
                    .bufferSize(64 * 1024 * 1024)            // 64 MB
                    .containerDir(containerDir)
                    .enableAutoFlush(false)                  // manual flush
                    .transparentMode(true)
                    .build();

            SmartHdfsClient client = SmartHdfsClient.create(smartConfig, hdfsUri, conf);
            System.out.println("       SmartHdfsClient created successfully.");

            // ---- 3. Generate random data and WRITE ----
            System.out.println("[3/5] Writing " + fileCount + " small files through SmartHdfsClient ...");

            Random rng = new Random(42); // deterministic seed
            byte[][] originalData = new byte[fileCount][];
            long totalBytesWritten = 0;

            String baseDir = "/smart_hdfs_demo/data";
            client.mkdirs(new Path(baseDir));

            long writeStartNanos = System.nanoTime();

            for (int i = 0; i < fileCount; i++) {
                int size = MIN_FILE_SIZE + rng.nextInt(MAX_FILE_SIZE - MIN_FILE_SIZE + 1);
                byte[] data = new byte[size];
                rng.nextBytes(data);
                originalData[i] = data;

                Path filePath = new Path(baseDir, "file_" + i + ".dat");
                try (OutputStream out = client.create(filePath)) {
                    out.write(data);
                }
                totalBytesWritten += size;
            }

            // Flush to ensure all buffered files go to SequenceFile containers
            client.flush();

            long writeEndNanos = System.nanoTime();
            long writeDurationMs = (writeEndNanos - writeStartNanos) / 1_000_000;
            System.out.println("       Write complete: " + fileCount + " files, "
                    + formatSize(totalBytesWritten) + " in " + writeDurationMs + " ms");

            // ---- 4. READ back and verify integrity ----
            System.out.println("[4/5] Reading back " + fileCount + " files and verifying integrity ...");

            long readStartNanos = System.nanoTime();
            int verifiedCount = 0;
            long totalBytesRead = 0;

            for (int i = 0; i < fileCount; i++) {
                Path filePath = new Path(baseDir, "file_" + i + ".dat");
                try (FSDataInputStream in = client.open(filePath)) {
                    byte[] buf = new byte[originalData[i].length];
                    in.readFully(buf);
                    totalBytesRead += buf.length;

                    if (!Arrays.equals(originalData[i], buf)) {
                        System.err.println("       MISMATCH on file " + i + "!");
                    } else {
                        verifiedCount++;
                    }
                }
            }

            long readEndNanos = System.nanoTime();
            long readDurationMs = (readEndNanos - readStartNanos) / 1_000_000;
            System.out.println("       Read complete:  " + verifiedCount + "/" + fileCount
                    + " verified, " + formatSize(totalBytesRead) + " in " + readDurationMs + " ms");

            // ---- 5. Gather container statistics ----
            System.out.println("[5/5] Collecting statistics ...");

            FileSystem rawFs = cluster.getFileSystem();
            Path containerPath = new Path(containerDir);

            int containerCount = 0;
            if (rawFs.exists(containerPath)) {
                containerCount = rawFs.listStatus(containerPath).length;
                // Filter out index files -- count only .seq files
                long seqCount = Arrays.stream(rawFs.listStatus(containerPath))
                        .filter(s -> s.getPath().getName().endsWith(".seq"))
                        .count();
                containerCount = (int) seqCount;
            }

            // Print summary
            System.out.println("\n================================================================");
            System.out.println("  RESULTS SUMMARY");
            System.out.println("================================================================");
            System.out.printf("  %-28s %s%n", "Files written:", fileCount);
            System.out.printf("  %-28s %s%n", "Files verified:", verifiedCount + "/" + fileCount);
            System.out.printf("  %-28s %s%n", "Total bytes written:", formatSize(totalBytesWritten));
            System.out.printf("  %-28s %s%n", "Total bytes read:", formatSize(totalBytesRead));
            System.out.printf("  %-28s %d ms%n", "Write time:", writeDurationMs);
            System.out.printf("  %-28s %d ms%n", "Read time:", readDurationMs);
            System.out.printf("  %-28s %s%n", "Write throughput:",
                    formatSize((long) throughputBytes(totalBytesWritten, writeDurationMs)) + "/s");
            System.out.printf("  %-28s %s%n", "Read throughput:",
                    formatSize((long) throughputBytes(totalBytesRead, readDurationMs)) + "/s");
            System.out.printf("  %-28s %d%n", "HDFS container files:", containerCount);
            if (fileCount > 0) {
                System.out.printf("  %-28s %.1f:1%n", "Aggregation ratio:",
                        (double) fileCount / Math.max(containerCount, 1));
            }
            System.out.println("================================================================");

            // Close client
            client.close();

        } finally {
            // ---- Shutdown cluster ----
            System.out.println("\nShutting down MiniDFSCluster ...");
            cluster.shutdown();
            System.out.println("Done.");
        }
    }

    // --------------------------------------------------------------------- //
    //  Helpers
    // --------------------------------------------------------------------- //

    private static double throughputBytes(long bytes, long durationMs) {
        if (durationMs <= 0) return 0;
        return (bytes * 1000.0) / durationMs;
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
