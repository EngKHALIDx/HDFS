package com.smarthdfs.benchmark;

import com.smarthdfs.client.SmartHdfsClient;
import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.MiniDFSCluster;

import java.io.OutputStream;
import java.util.Arrays;
import java.util.Random;

/**
 * RealBenchmark - Real comparison on a real HDFS MiniDFSCluster.
 * All measurements are actual wall-clock. No simulation.
 */
public class RealBenchmark {

    public static void main(String[] args) throws Exception {
        new RealBenchmark().run();
    }

    public void run() throws Exception {
        System.out.println("========================================================");
        System.out.println("  REAL BENCHMARK: Standard HDFS vs Smart HDFS Client");
        System.out.println("  Cluster: MiniDFSCluster (real in-process HDFS)");
        System.out.println("========================================================\n");

        Configuration conf = new Configuration();
        conf.set("dfs.replication", "1");

        MiniDFSCluster cluster = new MiniDFSCluster.Builder(conf)
                .format(true).numDataNodes(1).build();
        cluster.waitActive();

        String hdfsUri = cluster.getURI().toString();
        conf.set("fs.defaultFS", hdfsUri);
        FileSystem rawFs = cluster.getFileSystem();

        System.out.println("Cluster ready: " + hdfsUri);
        System.out.println();

        int[] fileCounts = {50, 100};
        int[] results = new int[fileCounts.length * 4]; // stdW, smartW, stdR, smartR per count

        try {
            for (int idx = 0; idx < fileCounts.length; idx++) {
                int N = fileCounts[idx];
                String stdDir = "/bench/std_" + N;
                String containerDir = "/bench/cont_" + N;

                // Cleanup
                rawFs.delete(new Path("/bench"), true);
                rawFs.mkdirs(new Path(stdDir));

                // Generate data
                Random rng = new Random(42);
                byte[][] data = new byte[N][];
                long totalBytes = 0;
                for (int i = 0; i < N; i++) {
                    int sz = 512 + rng.nextInt(512); // 512B - 1KB
                    data[i] = new byte[sz];
                    rng.nextBytes(data[i]);
                    totalBytes += sz;
                }

                // --- Standard HDFS Write ---
                long t0 = System.nanoTime();
                for (int i = 0; i < N; i++) {
                    try (OutputStream out = rawFs.create(new Path(stdDir, "f" + i + ".dat"), true)) {
                        out.write(data[i]);
                    }
                }
                results[idx * 4] = (int) ((System.nanoTime() - t0) / 1_000_000);

                // --- Smart HDFS Write ---
                SmartHdfsConfig cfg = SmartHdfsConfig.builder()
                        .smallFileThreshold(128 * 1024 * 1024)
                        .bufferSize(64 * 1024 * 1024)
                        .containerDir(containerDir)
                        .enableAutoFlush(false)
                        .transparentMode(true)
                        .build();

                SmartHdfsClient smart = SmartHdfsClient.create(cfg, hdfsUri, conf);
                t0 = System.nanoTime();
                for (int i = 0; i < N; i++) {
                    try (OutputStream out = smart.create(new Path(stdDir, "f" + i + ".dat"))) {
                        out.write(data[i]);
                    }
                }
                smart.flush();
                results[idx * 4 + 1] = (int) ((System.nanoTime() - t0) / 1_000_000);

                // --- Standard HDFS Read ---
                t0 = System.nanoTime();
                boolean ok = true;
                for (int i = 0; i < N; i++) {
                    try (FSDataInputStream in = rawFs.open(new Path(stdDir, "f" + i + ".dat"))) {
                        byte[] buf = new byte[data[i].length];
                        in.readFully(buf);
                        if (!Arrays.equals(data[i], buf)) ok = false;
                    }
                }
                results[idx * 4 + 2] = (int) ((System.nanoTime() - t0) / 1_000_000);

                // --- Smart HDFS Read ---
                t0 = System.nanoTime();
                int readOk = 0;
                for (int i = 0; i < N; i++) {
                    try (FSDataInputStream in = smart.open(new Path(stdDir, "f" + i + ".dat"))) {
                        byte[] buf = new byte[data[i].length];
                        int r = 0;
                        while (r < data[i].length) {
                            int n = in.read(buf, r, data[i].length - r);
                            if (n <= 0) break;
                            r += n;
                        }
                        if (r == data[i].length && Arrays.equals(data[i], buf)) readOk++;
                    }
                }
                results[idx * 4 + 3] = (int) ((System.nanoTime() - t0) / 1_000_000);

                // Count files
                int stdFiles = rawFs.listStatus(new Path(stdDir)).length;
                int containers = 0;
                try {
                    containers = rawFs.listStatus(new Path(containerDir)).length;
                } catch (Exception ignored) {}

                double writePct = results[idx * 4] > 0 ?
                        ((double)(results[idx * 4] - results[idx * 4 + 1]) / results[idx * 4] * 100) : 0;

                System.out.printf("N=%d files (%s total):%n", N, formatBytes(totalBytes));
                System.out.printf("  Standard Write:  %,d ms | Smart Write: %,d ms | Improvement: %.1f%%%n",
                        results[idx * 4], results[idx * 4 + 1], writePct);
                System.out.printf("  Standard Read:   %,d ms | Smart Read: %,d ms | Read OK: %d/%d%n",
                        results[idx * 4 + 2], results[idx * 4 + 3], readOk, N);
                System.out.printf("  HDFS Objects:    Standard=%d files | Smart=%d containers%n",
                        stdFiles, containers);
                System.out.printf("  Integrity: %s%n%n", ok && readOk == N ? "ALL VERIFIED" : "SOME FAILED");
            }

            System.out.println("========================================================");
            System.out.println("  *** All numbers from REAL HDFS operations ***");
            System.out.println("  *** MiniDFSCluster: real in-process HDFS ***");
            System.out.println("  *** Data integrity: verified byte-for-byte ***");
            System.out.println("========================================================");

        } finally {
            cluster.shutdown();
        }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.2f MB", bytes / (1024.0 * 1024));
    }
}
