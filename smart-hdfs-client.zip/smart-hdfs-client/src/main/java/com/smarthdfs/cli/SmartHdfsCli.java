package com.smarthdfs.cli;

import com.smarthdfs.benchmark.RealBenchmark;
import com.smarthdfs.config.SmartHdfsConfig;
import com.smarthdfs.demo.SmartHdfsDemo;

import java.util.Scanner;

/**
 * Command Line Interface for Smart HDFS Client.
 *
 * <p>Provides both an interactive menu and single-command mode for running
 * real HDFS demos and benchmarks backed by Hadoop's MiniDFSCluster.</p>
 *
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
public class SmartHdfsCli {

    private static final String VERSION = "1.0.0";
    private static final String BANNER =
            "\n" +
            "======================================================\n" +
            "           SMART HDFS CLIENT v" + VERSION + "\n" +
            "  Transparent Small Files Aggregation for HDFS\n" +
            "  Research Project Implementation\n" +
            "======================================================\n";

    private final Scanner scanner;
    private boolean running;

    public SmartHdfsCli() {
        this.scanner = new Scanner(System.in);
        this.running = true;
    }

    // --------------------------------------------------------------------- //
    //  Interactive mode
    // --------------------------------------------------------------------- //

    public void start() {
        System.out.println(BANNER);

        while (running) {
            showMainMenu();
            String choice = readInput("Enter your choice");
            processChoice(choice);
        }

        System.out.println("\nThank you for using Smart HDFS Client!");
        scanner.close();
    }

    private void showMainMenu() {
        System.out.println("\n--- MAIN MENU ---");
        System.out.println("  1. Run Real HDFS Demo (MiniDFSCluster)");
        System.out.println("  2. Run Real Benchmark (Standard vs Smart)");
        System.out.println("  3. Show Default Configuration");
        System.out.println("  4. Show Documentation");
        System.out.println("  5. Statistics Calculator");
        System.out.println("  0. Exit");
    }

    private void processChoice(String choice) {
        switch (choice.trim()) {
            case "1":
                runDemoInteractive();
                break;
            case "2":
                runBenchmarkInteractive();
                break;
            case "3":
                showConfiguration();
                break;
            case "4":
                showDocumentation();
                break;
            case "5":
                showStatisticsCalculator();
                break;
            case "0":
            case "q":
            case "quit":
            case "exit":
                running = false;
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void runDemoInteractive() {
        String input = readInput("Number of files [500]");
        int fileCount = 500;
        if (!input.isEmpty()) {
            try { fileCount = Integer.parseInt(input); } catch (NumberFormatException ignored) {}
        }
        System.out.println();
        try {
            new SmartHdfsDemo().run(fileCount);
        } catch (Exception e) {
            System.err.println("Demo failed: " + e.getMessage());
            e.printStackTrace();
        }
        waitForUser();
    }

    private void runBenchmarkInteractive() {
        System.out.println("\nRunning side-by-side benchmark (Standard HDFS vs Smart HDFS Client) ...\n");
        try {
            new RealBenchmark().run();
        } catch (Exception e) {
            System.err.println("Benchmark failed: " + e.getMessage());
            e.printStackTrace();
        }
        waitForUser();
    }

    // --------------------------------------------------------------------- //
    //  Info screens
    // --------------------------------------------------------------------- //

    private void showConfiguration() {
        SmartHdfsConfig config = new SmartHdfsConfig();

        System.out.println("\n--- DEFAULT CONFIGURATION ---");
        System.out.println("  Block Size:             " + formatBytes(config.getBlockSize()));
        System.out.println("  Small File Threshold:   " + formatBytes(config.getSmallFileThreshold()));
        System.out.println("  Buffer Size:            " + formatBytes(config.getBufferSize()));
        System.out.println("  Flush Interval:         " + config.getFlushIntervalMs() + " ms");
        System.out.println("  Auto Flush:             " + config.isEnableAutoFlush());
        System.out.println("  Transparent Mode:       " + config.isTransparentMode());
        System.out.println("  Container Directory:    " + config.getContainerDir());
    }

    private void showDocumentation() {
        System.out.println("\n--- DOCUMENTATION ---\n");
        System.out.println("OVERVIEW:");
        System.out.println("  The Smart HDFS Client is a Java library that transparently");
        System.out.println("  aggregates small files in HDFS to reduce NameNode memory");
        System.out.println("  consumption and improve performance.\n");
        System.out.println("KEY FEATURES:");
        System.out.println("  * Transparent file aggregation");
        System.out.println("  * Automatic small file detection");
        System.out.println("  * SequenceFile container format (Apache Hadoop)");
        System.out.println("  * Side-car index for fast lookups");
        System.out.println("  * No application code changes required\n");
        System.out.println("USAGE EXAMPLE:");
        System.out.println("  SmartHdfsConfig config = SmartHdfsConfig.builder()");
        System.out.println("      .smallFileThreshold(128 * 1024 * 1024)");
        System.out.println("      .bufferSize(64 * 1024 * 1024)");
        System.out.println("      .build();");
        System.out.println("  SmartHdfsClient client = SmartHdfsClient.create(config, uri);");
        System.out.println("  OutputStream out = client.create(new Path(\"/data/file.txt\"));");
        System.out.println("  out.write(data);");
        System.out.println("  out.close();\n");
    }

    private void showStatisticsCalculator() {
        String input1 = readInput("Number of small files [10000]");
        long fileCount = 10000;
        if (!input1.isEmpty()) {
            try { fileCount = Long.parseLong(input1); } catch (NumberFormatException ignored) {}
        }

        String input2 = readInput("Average file size in bytes [102400]");
        long avgFileSize = 100 * 1024;
        if (!input2.isEmpty()) {
            try { avgFileSize = Long.parseLong(input2); } catch (NumberFormatException ignored) {}
        }

        long totalDataSize = fileCount * avgFileSize;
        long stdMem = fileCount * 150;

        long containerSize = 128L * 1024 * 1024;
        long containers = (long) Math.ceil((double) totalDataSize / containerSize);
        long smartMem = containers * 150;

        double savings = stdMem == 0 ? 0 : ((double) (stdMem - smartMem) / stdMem) * 100;

        System.out.println("\n--- CALCULATION RESULTS ---");
        System.out.println("  Total Data Size:    " + formatBytes(totalDataSize));
        System.out.println("  Standard NameNode:   " + formatBytes(stdMem) + "  (" + fileCount + " files)");
        System.out.println("  Smart NameNode:      " + formatBytes(smartMem) + "  (" + containers + " containers)");
        System.out.println("  Reduction Ratio:     " + String.format("%.1f:1", (double) fileCount / Math.max(containers, 1)));
        System.out.println("  Memory Savings:      " + String.format("%.1f%%", savings));
    }

    // --------------------------------------------------------------------- //
    //  Helpers
    // --------------------------------------------------------------------- //

    private String readInput(String prompt) {
        System.out.print("\n" + prompt + ": ");
        return scanner.nextLine().trim();
    }

    private void waitForUser() {
        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    // --------------------------------------------------------------------- //
    //  Command-line mode
    // --------------------------------------------------------------------- //

    public static void main(String[] args) {
        if (args.length > 0) {
            handleCommandLineArgs(args);
            return;
        }

        new SmartHdfsCli().start();
    }

    private static void handleCommandLineArgs(String[] args) {
        String command = args[0].toLowerCase();

        switch (command) {
            case "demo":
                int fileCount = args.length > 1 ? Integer.parseInt(args[1]) : 500;
                try {
                    new SmartHdfsDemo().run(fileCount);
                } catch (Exception e) {
                    System.err.println("Demo failed: " + e.getMessage());
                    e.printStackTrace();
                }
                break;

            case "benchmark":
                try {
                    new RealBenchmark().run();
                } catch (Exception e) {
                    System.err.println("Benchmark failed: " + e.getMessage());
                    e.printStackTrace();
                }
                break;

            case "help":
            case "--help":
            case "-h":
                printHelp();
                break;

            case "version":
            case "--version":
            case "-v":
                System.out.println("Smart HDFS Client v" + VERSION);
                break;

            default:
                System.out.println("Unknown command: " + command);
                printHelp();
        }
    }

    private static void printHelp() {
        System.out.println("\nSmart HDFS Client v" + VERSION);
        System.out.println("Usage: smart-hdfs-cli [command] [options]\n");
        System.out.println("Commands:");
        System.out.println("  demo [count]     Run real HDFS demo with specified file count (default 500)");
        System.out.println("  benchmark        Run side-by-side benchmark (Standard vs Smart HDFS)");
        System.out.println("  help             Show this help message");
        System.out.println("  version          Show version information\n");
        System.out.println("Interactive mode:  Run without arguments to start interactive CLI");
    }
}
