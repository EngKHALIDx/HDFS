package com.smarthdfs.interception;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.PositionedReadable;
import org.apache.hadoop.fs.Seekable;

import java.io.IOException;
import java.io.InputStream;

/**
 * SeekableByteArrayStream - An InputStream that also implements Seekable
 * so it can be wrapped in FSDataInputStream.
 */
class SeekableByteArrayStream extends InputStream implements Seekable, PositionedReadable {
    private final byte[] data;
    private int pos;

    SeekableByteArrayStream(byte[] data) {
        this.data = data;
        this.pos = 0;
    }

    @Override
    public int read() throws IOException {
        if (pos >= data.length) return -1;
        return data[pos++] & 0xFF;
    }

    @Override
    public int read(byte[] b, int off, int len) throws IOException {
        if (pos >= data.length) return -1;
        int available = data.length - pos;
        int toRead = Math.min(len, available);
        System.arraycopy(data, pos, b, off, toRead);
        pos += toRead;
        return toRead;
    }

    @Override
    public void seek(long targetPos) throws IOException {
        if (targetPos < 0 || targetPos > data.length) {
            throw new IOException("Seek out of bounds: " + targetPos);
        }
        this.pos = (int) targetPos;
    }

    @Override
    public long getPos() throws IOException {
        return pos;
    }

    @Override
    public boolean seekToNewSource(long targetPos) throws IOException {
        seek(targetPos);
        return true;
    }

    @Override
    public int read(long position, byte[] buffer, int offset, int length) throws IOException {
        if (position < 0 || position >= data.length) return -1;
        int available = (int) (data.length - position);
        int toRead = Math.min(length, available);
        System.arraycopy(data, (int) position, buffer, offset, toRead);
        return toRead;
    }

    @Override
    public void readFully(long position, byte[] buffer, int offset, int length) throws IOException {
        int n = read(position, buffer, offset, length);
        if (n < length) throw new IOException("End of stream");
    }

    @Override
    public void readFully(long position, byte[] buffer) throws IOException {
        readFully(position, buffer, 0, buffer.length);
    }

    public byte[] getData() {
        return data;
    }
}
