package com.smarthdfs.interception;

import org.apache.hadoop.fs.FSDataInputStream;

import java.io.IOException;

/**
 * ByteArrayFSDataInputStream - A wrapper around byte array data that provides
 * HDFS-compatible input stream with seek and positioned read capabilities.
 * Used to return data from aggregated files through the standard API.
 */
public class ByteArrayFSDataInputStream extends FSDataInputStream {

    public ByteArrayFSDataInputStream(byte[] data) {
        super(new SeekableByteArrayStream(data));
    }

    /**
     * Get the total size of the data
     * @return The size in bytes
     */
    public int getSize() {
        if (in instanceof SeekableByteArrayStream) {
            return ((SeekableByteArrayStream) in).getData().length;
        }
        return -1;
    }
}
