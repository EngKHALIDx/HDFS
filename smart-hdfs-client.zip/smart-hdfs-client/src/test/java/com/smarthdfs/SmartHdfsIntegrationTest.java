package com.smarthdfs;

import com.smarthdfs.client.SmartHdfsClient;
import com.smarthdfs.config.SmartHdfsConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.MiniDFSCluster;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.OutputStream;
import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for Smart HDFS Client using a real MiniDFSCluster.
 *
 * <p>Every test creates an in-process HDFS cluster, exercises the SmartHdfsClient
 * through the real Hadoop FileSystem / SequenceFile APIs, and verifies correctness.</p>
 *
 * @author Smart HDFS Research Team
 * @version 1.0.0
 */
class SmartHdfsIntegrationTest {

    private MiniDFSCluster cluster;
    private Configuration conf;
    private String hdfsUri;
    private FileSystem rawFs;

    @TempDir
    java.nio.file.Path nioTempDir;   // JUnit 5 temporary directory for MiniDFSCluster data

    @BeforeEach
    void setUp() throws Exception {
        conf = new Configuration();
        // Point Hadoop at the temp directory so MiniDFSCluster uses it
        conf.set(MiniDFSCluster.HDFS_MINIDFS_BASEDIR, nioTempDir.toString());

        cluster = new MiniDFSCluster.Builder(conf)
                .format(true)
                .numDataNodes(1)
                .build();
        cluster.waitActive();

        hdfsUri = cluster.getURI().toString();
        conf.set("fs.defaultFS", hdfsUri);
        rawFs = cluster.getFileSystem();
    }

    @AfterEach
    void tearDown() {
        if (cluster != null) {
            cluster.shutdown();
        }
    }

    // --------------------------------------------------------------------- //
    //  Test: Write 100 small files, read them back, verify content
    // --------------------------------------------------------------------- //

    @Test
    void testWriteAndReadSmallFiles() throws Exception {
        int fileCount = 100;
        String testDir = "/itest_small_files";
        String containerDir = "/itest_small_files_containers";

        SmartHdfsConfig config = SmartHdfsConfig.builder()
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)
                .containerDir(containerDir)
                .enableAutoFlush(false)
                .transparentMode(true)
                .build();

        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, conf);
        client.mkdirs(new Path(testDir));

        // Generate random data and write
        Random rng = new Random(99);
        byte[][] originalData = new byte[fileCount][];

        for (int i = 0; i < fileCount; i++) {
            int size = 512 + rng.nextInt(2048); // 512 B - 2.5 KB
            byte[] data = new byte[size];
            rng.nextBytes(data);
            originalData[i] = data;

            Path filePath = new Path(testDir, "file_" + i + ".dat");
            try (OutputStream out = client.create(filePath)) {
                out.write(data);
            }
        }

        // Flush so everything is written to containers
        client.flush();

        // Read back and verify
        for (int i = 0; i < fileCount; i++) {
            Path filePath = new Path(testDir, "file_" + i + ".dat");
            try (FSDataInputStream in = client.open(filePath)) {
                byte[] buf = new byte[originalData[i].length];
                in.readFully(buf);
                assertArrayEquals(originalData[i], buf,
                        "Data mismatch for file_" + i + ".dat");
            }
        }

        client.close();
    }

    // --------------------------------------------------------------------- //
    //  Test: Aggregation reduces the number of HDFS container files
    // --------------------------------------------------------------------- //

    @Test
    void testAggregationReducesFileCount() throws Exception {
        int fileCount = 200;
        String testDir = "/itest_aggregation";
        String containerDir = "/itest_aggregation_containers";

        SmartHdfsConfig config = SmartHdfsConfig.builder()
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)   // large buffer so all files go into 1 container
                .containerDir(containerDir)
                .enableAutoFlush(false)
                .transparentMode(true)
                .build();

        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, conf);
        client.mkdirs(new Path(testDir));

        Random rng = new Random(77);
        for (int i = 0; i < fileCount; i++) {
            byte[] data = new byte[1024]; // 1 KB each
            rng.nextBytes(data);

            Path filePath = new Path(testDir, "agg_file_" + i + ".dat");
            try (OutputStream out = client.create(filePath)) {
                out.write(data);
            }
        }

        client.flush();

        // Count the SequenceFile containers created
        Path containerPath = new Path(containerDir);
        assertTrue(rawFs.exists(containerPath), "Container directory should exist");

        long seqFileCount = Arrays.stream(rawFs.listStatus(containerPath))
                .filter(s -> s.getPath().getName().endsWith(".seq"))
                .count();

        // With 200 * 1 KB = 200 KB of data and a 64 MB buffer, there should be
        // far fewer container files than the original 200 small files.
        assertTrue(seqFileCount < fileCount,
                "Container files (" + seqFileCount + ") should be fewer than original files (" + fileCount + ")");
        assertTrue(seqFileCount >= 1,
                "At least one container file should have been created");

        client.close();
    }

    // --------------------------------------------------------------------- //
    //  Test: A file larger than the threshold is written directly (not aggregated)
    // --------------------------------------------------------------------- //

    @Test
    void testLargeFileDirectWrite() throws Exception {
        // Use a very small threshold so our test file counts as "large"
        String testDir = "/itest_large_file";
        String containerDir = "/itest_large_file_containers";

        SmartHdfsConfig config = SmartHdfsConfig.builder()
                .smallFileThreshold(4 * 1024)   // 4 KB threshold
                .bufferSize(64 * 1024 * 1024)
                .containerDir(containerDir)
                .enableAutoFlush(false)
                .transparentMode(true)
                .build();

        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, conf);
        client.mkdirs(new Path(testDir));

        // Generate a file clearly above the threshold
        int largeFileSize = 16 * 1024; // 16 KB > 4 KB threshold
        byte[] largeData = new byte[largeFileSize];
        new Random(55).nextBytes(largeData);

        Path largeFilePath = new Path(testDir, "large_file.dat");
        try (OutputStream out = client.create(largeFilePath)) {
            out.write(largeData);
        }

        // Flush in case anything was buffered
        client.flush();

        // Read back and verify
        try (FSDataInputStream in = client.open(largeFilePath)) {
            byte[] buf = new byte[largeData.length];
            in.readFully(buf);
            assertArrayEquals(largeData, buf, "Large file data should match after direct write");
        }

        client.close();
    }

    // --------------------------------------------------------------------- //
    //  Test: Files can be found via the client (exists check) after write
    // --------------------------------------------------------------------- //

    @Test
    void testDeleteAggregatedFile() throws Exception {
        int fileCount = 50;
        String testDir = "/itest_delete";
        String containerDir = "/itest_delete_containers";

        SmartHdfsConfig config = SmartHdfsConfig.builder()
                .smallFileThreshold(128 * 1024 * 1024)
                .bufferSize(64 * 1024 * 1024)
                .containerDir(containerDir)
                .enableAutoFlush(false)
                .transparentMode(true)
                .build();

        SmartHdfsClient client = SmartHdfsClient.create(config, hdfsUri, conf);
        client.mkdirs(new Path(testDir));

        Random rng = new Random(33);
        for (int i = 0; i < fileCount; i++) {
            byte[] data = new byte[512];
            rng.nextBytes(data);

            Path filePath = new Path(testDir, "del_file_" + i + ".dat");
            try (OutputStream out = client.create(filePath)) {
                out.write(data);
            }
        }

        client.flush();

        // Verify all files can be found via the client's exists() / open()
        for (int i = 0; i < fileCount; i++) {
            Path filePath = new Path(testDir, "del_file_" + i + ".dat");
            assertTrue(client.exists(filePath),
                    "File del_file_" + i + ".dat should exist after aggregation");

            // Also verify we can open and read the file
            try (FSDataInputStream in = client.open(filePath)) {
                assertNotNull(in, "Should be able to open aggregated file " + i);
            }
        }

        client.close();
    }
}
